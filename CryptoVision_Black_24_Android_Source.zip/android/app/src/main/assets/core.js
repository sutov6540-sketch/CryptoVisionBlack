/* Crypto Vision Pro — standalone indicator and analysis engine. No order placement. */
(function(root, factory) { const core = factory(); if (typeof module !== 'undefined' && module.exports) module.exports = core; root.CVCore = core; })(typeof globalThis !== 'undefined' ? globalThis : this, function() {
'use strict';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const avg=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:0;
const sum=a=>a.reduce((s,x)=>s+x,0);
const last=a=>a[a.length-1];
const round=(x,d=4)=>Number(Number(x).toFixed(d));
function ema(values,n) { if(!values.length) return []; const k=2/(n+1); let previous=values[0]; return values.map((x,i)=> i===0 ? previous : (previous=x*k+previous*(1-k))); }
function sma(values,n){return values.map((_,i)=>i+1>=n?avg(values.slice(i-n+1,i+1)):null);}
function rsi(values,n=14){const out=Array(values.length).fill(null);if(values.length<=n)return out;let up=0,down=0;for(let i=1;i<=n;i++){const delta=values[i]-values[i-1];up+=Math.max(0,delta);down+=Math.max(0,-delta);}up/=n;down/=n;const calc=()=>down===0?(up===0?50:100):100-100/(1+up/down);out[n]=calc();for(let i=n+1;i<values.length;i++){let d=values[i]-values[i-1];up=(up*(n-1)+Math.max(0,d))/n;down=(down*(n-1)+Math.max(0,-d))/n;out[i]=calc();}return out;}
function atr(candles,n=14){const tr=candles.map((c,i)=>i?Math.max(c.high-c.low,Math.abs(c.high-candles[i-1].close),Math.abs(c.low-candles[i-1].close)):c.high-c.low);let out=Array(candles.length).fill(null);if(candles.length<n)return out;let value=avg(tr.slice(0,n));out[n-1]=value;for(let i=n;i<tr.length;i++){value=(value*(n-1)+tr[i])/n;out[i]=value;}return out;}
function adx(candles,n=14){const len=candles.length,out=Array(len).fill(null),plus=Array(len).fill(null),minus=Array(len).fill(null);if(len<2*n+1)return {adx:out,plus,minus};const tr=[],pd=[],md=[];for(let i=1;i<len;i++){const cur=candles[i],prev=candles[i-1],u=cur.high-prev.high,d=prev.low-cur.low;pd[i]=u>d&&u>0?u:0;md[i]=d>u&&d>0?d:0;tr[i]=Math.max(cur.high-cur.low,Math.abs(cur.high-prev.close),Math.abs(cur.low-prev.close));}let smoothT=sum(tr.slice(1,n+1)),smoothP=sum(pd.slice(1,n+1)),smoothM=sum(md.slice(1,n+1));const dx=Array(len).fill(null);for(let i=n;i<len;i++){if(i>n){smoothT=smoothT-smoothT/n+tr[i];smoothP=smoothP-smoothP/n+pd[i];smoothM=smoothM-smoothM/n+md[i];}plus[i]=smoothT>0?100*smoothP/smoothT:0;minus[i]=smoothT>0?100*smoothM/smoothT:0;dx[i]=(plus[i]+minus[i])?100*Math.abs(plus[i]-minus[i])/(plus[i]+minus[i]):0;}let value=avg(dx.slice(n,2*n));out[2*n-1]=value;for(let i=2*n;i<len;i++){value=(value*(n-1)+dx[i])/n;out[i]=value;}return {adx:out,plus,minus};}
function indicators(c){if(c.length<205)throw Error('Для EMA200 требуется минимум 205 закрытых свечей');const close=c.map(x=>x.close),volume=c.map(x=>x.volume),e20=ema(close,20),e50=ema(close,50),e200=ema(close,200),e12=ema(close,12),e26=ema(close,26),m=e12.map((x,i)=>x-e26[i]),ms=ema(m,9),r=rsi(close),a=atr(c),d=adx(c),mean=sma(close,20),bbDev=close.map((_,i)=>i<19?null:Math.sqrt(avg(close.slice(i-19,i+1).map(x=>(x-mean[i])**2))));const i=c.length-1;const volBase=avg(volume.slice(-21,-1));let high30=Math.max(...c.slice(-31,-4).map(x=>x.high)),low30=Math.min(...c.slice(-31,-4).map(x=>x.low));const prev=c[i-1],curr=c[i],body=Math.abs(curr.close-curr.open),range=Math.max(curr.high-curr.low,1e-12);const upper=curr.high-Math.max(curr.close,curr.open),lower=Math.min(curr.close,curr.open)-curr.low;let patterns=[];if(curr.close>curr.open&&prev.close<prev.open&&curr.close>=prev.open&&curr.open<=prev.close)patterns.push('Бычье поглощение');if(curr.close<curr.open&&prev.close>prev.open&&curr.open>=prev.close&&curr.close<=prev.open)patterns.push('Медвежье поглощение');if(lower>2*body&&upper<range*.25)patterns.push('Длинная нижняя тень');if(upper>2*body&&lower<range*.25)patterns.push('Длинная верхняя тень');return {close:close[i],e20:e20[i],e50:e50[i],e200:e200[i],rsi:r[i],atr:a[i],atrPct:100*a[i]/close[i],adx:d.adx[i],diPlus:d.plus[i],diMinus:d.minus[i],macd:m[i],macdSignal:ms[i],macdHist:m[i]-ms[i],macdHistPrev:m[i-1]-ms[i-1],macdHistPrev2:m[i-2]-ms[i-2],closePrev:close[i-1],volumeRatio:volBase>0?volume[i]/volBase:0,bbUpper:mean[i]+2*bbDev[i],bbLower:mean[i]-2*bbDev[i],high30,low30,patterns,series:{ema20:e20,ema50:e50,ema200:e200,bbUpper:mean.map((x,j)=>x===null?null:x+2*bbDev[j]),bbLower:mean.map((x,j)=>x===null?null:x-2*bbDev[j])}};}
function evaluate(c, higher=null, prefs={}){const t=indicators(c), reasons=[],warnings=[];let score=0;function factor(s,label,description){score+=s;reasons.push({score:s,label,description});}
const close=t.close;
factor(close>t.e200?2:-2,'Основной тренд',`Цена ${close>t.e200?'выше':'ниже'} EMA 200; медленный фильтр ${close>t.e200?'бычий':'медвежий'}.`);
factor(t.e20>t.e50?1.5:-1.5,'Положение EMA',`EMA 20 ${t.e20>t.e50?'выше':'ниже'} EMA 50.`);
factor(t.macdHist>0?1.3:-1.3,'Импульс MACD',`Гистограмма ${t.macdHist>0?'положительная':'отрицательная'} (${round(t.macdHist,6)}).`);
const momentum=t.rsi>=55&&t.rsi<=72?1:t.rsi<=45&&t.rsi>=28?-1:0;
factor(momentum,'RSI',`RSI(14) = ${round(t.rsi,1)}. ${t.rsi>=72?'Сильная перекупленность; вход вверх опаснее.':t.rsi<=28?'Сильная перепроданность; вход вниз опаснее.':'Нет экстремального значения.'}`);
if(t.adx>=23){factor(t.diPlus>t.diMinus?1:-1,'Сила движения',`ADX ${round(t.adx,1)} — выраженное направленное движение; DI+ ${round(t.diPlus,1)}, DI− ${round(t.diMinus,1)}.`);}else{factor(0,'Сила движения',`ADX ${round(t.adx,1)} — боковик либо слабый тренд.`);warnings.push('ADX ниже 23: повышен риск ложных сигналов в боковике.');}
const bar=c[c.length-1],prev=c[c.length-2],move=bar.close-prev.close;
if(t.volumeRatio>=1.4){factor(Math.sign(move)*.7,'Подтверждение объёмом',`Объём ${round(t.volumeRatio,2)}× среднего за 20 свечей.`);}else{factor(0,'Объём',`Объём ${round(t.volumeRatio,2)}× среднего; сильного подтверждения нет.`);}
if(higher){const bullish=higher.close>higher.e200&&higher.e20>higher.e50;const bearish=higher.close<higher.e200&&higher.e20<higher.e50;factor(bullish?1.6:bearish?-1.6:0,'Старший таймфрейм',bullish?'На старшем интервале восходящий тренд.':bearish?'На старшем интервале нисходящий тренд.':'На старшем интервале направление неоднозначно.');}else warnings.push('Старший таймфрейм не проверен — сигнал менее надёжен.');
const resistance=t.high30,support=t.low30,distResistance=(resistance-close)/close*100,distSupport=(close-support)/close*100;
if(t.atrPct>=5)warnings.push(`Высокая волатильность: ATR равен ${round(t.atrPct,2)}% цены.`);
if(t.rsi>=75)warnings.push('RSI сильно перегрет для LONG.');if(t.rsi<=25)warnings.push('RSI сильно перепродан для SHORT.');
if(t.volumeRatio<.55)warnings.push('Аномально низкий объём — проскальзывание и шум.');
const direction=score>=4?'LONG':score<=-4?'SHORT':'WAIT';
const atrStop=Math.max(t.atr*1.65,close*.002);let stop,target,rr=1.9,blocking=false;
if(direction==='LONG'){stop=Math.min(close-atrStop,support-t.atr*.12);const risk=close-stop;target=close+risk*rr;if(resistance>close&&resistance-close<risk*1.25){warnings.push('Сопротивление близко к входу: потенциал роста ограничен.');blocking=true;}}
if(direction==='SHORT'){stop=Math.max(close+atrStop,resistance+t.atr*.12);const risk=stop-close;target=close-risk*rr;if(support<close&&close-support<risk*1.25){warnings.push('Поддержка близко к входу: потенциал снижения ограничен.');blocking=true;}}
if(Math.abs(score)<5)warnings.push('Большая часть индикаторов даёт умеренное, а не сильное согласие.');
const overextended=(direction==='LONG'&&close>t.e20+t.atr*4.5)||(direction==='SHORT'&&close<t.e20-t.atr*4.5);if(overextended)warnings.push('Цена далеко от EMA20; возможен откат перед продолжением тренда.');
// Two prior closed candles must support the slow/fast EMA ordering before a
// crossover can be treated as confirmed rather than just a fresh impulse.
const emaRecent=t.series.ema20.slice(-3,-1).map((v,i)=>v-t.series.ema50[t.series.ema50.length-3+i]);
const freshCrossover=direction==='LONG'?emaRecent.some(v=>v<=0):direction==='SHORT'?emaRecent.some(v=>v>=0):false;
if(freshCrossover)warnings.push('Недавнее пересечение EMA20/50: дождитесь закрепления направления на закрытых свечах.');
// A confirmed signal requires a usable higher timeframe, sufficient liquidity,
// and no clearly opposite higher-trend structure. Otherwise show only a leaning.
const olderOpposes=!!higher&&((direction==='LONG'&&higher.close<higher.e200&&higher.e20<higher.e50)||
  (direction==='SHORT'&&higher.close>higher.e200&&higher.e20>higher.e50));
if(olderOpposes)warnings.push('Старший интервал противоречит выбранному направлению.');
let verdict=direction;
const exhaustedMomentum=(direction==='LONG'&&t.rsi>=75)||(direction==='SHORT'&&t.rsi<=25);
if(direction!=='WAIT'&&(blocking||overextended||freshCrossover||exhaustedMomentum||t.adx<18||t.atrPct>=7||t.volumeRatio<.55||!higher||olderOpposes))verdict='WAIT';
if(verdict==='WAIT'){stop=null;target=null;}
const confidence=clamp(Math.round((Math.abs(score)/10.1)*100),0,100);
return {direction:verdict,bias:direction,score:round(score,1),agreement:confidence,entry:close,stop,target,rr:verdict==='WAIT'?null:rr,indicators:t,reasons,warnings,support,resistance,distSupport,distResistance,description:verdict==='WAIT'?'Условия не подтверждают вход.':verdict==='LONG'?'Преобладает восходящий сценарий, но он может не реализоваться.':'Преобладает нисходящий сценарий, но он может не реализоваться.'};}
/* Frequency among similar *past* closed-candle conditions.
   Deliberately not called a calibrated probability; overlapping examples are dependent.
   No future candle is ever used to build a historical comparison feature. */
/* Wilson interval is a description of sample uncertainty ONLY. Market
   examples are not IID, so this is not a predictive confidence guarantee. */
function sampleInterval(successes,n){
  if(!Number.isInteger(n)||n<=0||!Number.isInteger(successes)||successes<0||successes>n)return null;
  const z=1.959963984540054, p=successes/n, z2=z*z, denominator=1+z2/n;
  const center=(p+z2/(2*n))/denominator;
  const margin=z*Math.sqrt((p*(1-p)+z2/(4*n))/n)/denominator;
  return {low:round(100*Math.max(0,center-margin),1),high:round(100*Math.min(1,center+margin),1)};
}
/* For a return measured h candles after the analogue, an exchange gap must
   not silently turn a 12-candle horizon into a much longer period. */
function marketCadence(candles){
  const gaps=[];
  for(let i=Math.max(1,candles.length-101);i<candles.length;i++){
    const delta=candles[i].time-candles[i-1].time;
    if(Number.isFinite(delta)&&delta>0)gaps.push(delta);
  }
  if(gaps.length<10)return null;
  gaps.sort((a,b)=>a-b);
  // Most recent minimum cadence is the base interval, not a multi-bar outage.
  const q=gaps[Math.floor(gaps.length*.15)];
  return Number.isFinite(q)&&q>0?q:null;
}
function outlook(candles, feePct=.055){
  if(!Array.isArray(candles)||candles.length<265) return {available:false,reason:'Для оценки требуется не менее 265 закрытых свечей.'};
  const cadence=marketCadence(candles);
  if(!cadence)return {available:false,reason:'Невозможно определить интервал истории.'};
  const close=candles.map(v=>v.close);
  const e20=ema(close,20),e50=ema(close,50),e200=ema(close,200),r=rsi(close,14),a=atr(candles,14),d=adx(candles,14);
  function vals(i){const atrUnit=Math.max(a[i]||close[i]*.001,close[i]*.0002);
    return [(e20[i]-e50[i])/atrUnit,(close[i]-e200[i])/atrUnit,(r[i]-50)/15,(d.adx[i]-22)/15,(close[i]-e20[i])/atrUnit];}
  const target=vals(candles.length-1),horizons=[3,12,36];
  if(!target.every(Number.isFinite))return {available:false,reason:'Неполные данные индикаторов для сравнения.',horizons:[]};
  const brokenPrefix=new Uint16Array(candles.length);
  for(let j=1;j<candles.length;j++){
    brokenPrefix[j]=brokenPrefix[j-1]+(Math.abs(candles[j].time-candles[j-1].time-cadence)>cadence*.05?1:0);
  }
  // The current target must also have an uninterrupted 200-candle lookback:
  // comparing a broken recent regime with clean historical examples is unsafe.
  if(brokenPrefix.at(-1)!==brokenPrefix[Math.max(0,candles.length-201)])
    return {available:false,reason:'В последних 200 свечах есть пропуски: историческая оценка недоступна.',horizons:[]};
  // A historical feature at i depends on its previous ~200 candles. Do not
  // use it if that feature or its future horizon crosses a missing bar.
  const uninterrupted=(start,end)=>brokenPrefix[end]===brokenPrefix[start];
  const feeCost=Math.max(0,Number(feePct)||0)*2/100;
  const segments=horizons.map(h=>{
    const candidates=[];
    for(let i=210;i<candles.length-1-h;i++){
      // A forward gap invalidates this particular historical outcome.
      if(Math.abs((candles[i+h].time-candles[i].time)-h*cadence)>cadence*.05||
         !uninterrupted(Math.max(0,i-200),i+h))continue;
      const v=vals(i);if(!v.every(Number.isFinite)||close[i]<=0)continue;
      const similarity=Math.sqrt(v.reduce((acc,x,k)=>acc+(Math.min(10,Math.abs(x-target[k]))/([1.5,2.4,1.6,1.8,1.4][k]))**2,0));
      // If a regime is not represented in history, do not force a numerical
      // success percentage from distant, dissimilar market conditions.
      if(!Number.isFinite(similarity)||similarity>3.2)continue;
      const gross=100*(close[i+h]/close[i]-1);
      candidates.push({similarity,gross,index:i});
    }
    candidates.sort((x,y)=>x.similarity-y.similarity);
    // Favor distinct historical outcomes rather than dozens of overlapping windows.
    const chosen=[];const minGap=Math.max(2,Math.round(h*.85));
    for(const point of candidates){
      if(chosen.every(x=>Math.abs(x.index-point.index)>minGap)){chosen.push(point);if(chosen.length>=45)break;}
    }
    if(chosen.length<12)return {bars:h,available:false,sample:chosen.length};
    const avgDistance=avg(chosen.map(x=>x.similarity)),sample=chosen.length;
    const longNet=chosen.map(x=>x.gross-feeCost*100);
    const shortNet=chosen.map(x=>-x.gross-feeCost*100);
    // Modest regularization towards uncertainty (50%) rather than reporting 0% or 100%.
    // This is an exploratory estimate, not a calibrated conditional probability.
    const prior=Math.max(8,Math.round(h/3));
    const freq=x=>100*(x.filter(v=>v>0).length+prior/2)/(sample+prior);
    const longWins=longNet.filter(v=>v>0).length,shortWins=shortNet.filter(v=>v>0).length;
    const intervalLong=sampleInterval(longWins,sample), intervalShort=sampleInterval(shortWins,sample);
    const median=x=>{const sorted=[...x].sort((a,b)=>a-b);return (sorted[Math.floor((sample-1)/2)]+sorted[Math.floor(sample/2)])/2;};
    const medianMove=median(chosen.map(x=>Math.abs(x.gross)));
    const dispersion=avg(chosen.map(x=>Math.abs(x.gross)));
    return {bars:h,available:true,sample,match:round(avgDistance,2),long:round(freq(longNet),1),short:round(freq(shortNet),1),
      longWins,shortWins,intervalLong,intervalShort,
      medianLongPct:round(median(longNet),2),medianShortPct:round(median(shortNet),2),
      medianMovePct:round(medianMove,2),avgMovePct:round(dispersion,2),feePct:round(feeCost*100,3)};
  });
  const now=indicators(candles),atrRatio=now.atrPct,trendAdx=now.adx;
  const nearTop=(now.high30>now.close)?(now.high30/now.close-1)*100:null;
  const nearBottom=(now.low30<now.close)?(1-now.low30/now.close)*100:null;
  const qualified=segments.filter(x=>x.available);
  if(!qualified.length)return {available:false,reason:'Недостаточно исторических аналогов.',horizons:segments};
  // Main number corresponds to the selected timeframe holding period, not an optimized outcome.
  // The headline is explicitly a 12-candle estimate. Falling back to a 3-
  // or 36-candle sample while retaining the '12 candles' label misrepresents
  // the holding period. Without enough 12-candle analogues, show no headline.
  const preferred=qualified.find(x=>x.bars===12);
  if(!preferred)return {available:false,reason:'Недостаточно аналогов для основного горизонта 12 свечей.',horizons:segments};
  const advantage=preferred.long-preferred.short;
  const bias=advantage>8?'LONG':advantage< -8?'SHORT':'WAIT';
  const primary=preferred[bias==='SHORT'?'short':'long'];
  const quick=qualified.find(x=>x.bars===3),extended=qualified.find(x=>x.bars===36);
  const longSupport=trendAdx>=24 && !!extended && !!quick && (extended[bias==='SHORT'?'short':'long']>=quick[bias==='SHORT'?'short':'long']-4);
  const headroom=bias==='LONG'?nearTop:bias==='SHORT'?nearBottom:(nearTop??nearBottom);
  let durationType='Неопределённо',durationBars=12;
  if(bias!=='WAIT'){
    if(longSupport && extended.sample>=12 && (headroom===null || headroom>atrRatio*.65)){durationType='Возможен продолжительный тренд';durationBars=36;}
    else if(quick && (trendAdx<22||(headroom!==null && headroom<=atrRatio*.65)||quick[bias==='SHORT'?'short':'long']>=primary+7)){
      durationType='Вероятнее короткий импульс';durationBars=3;
    }else{durationType='Среднесрочное движение';durationBars=12;}
  }
  const selected=qualified.find(x=>x.bars===durationBars)||preferred;
  const gain=selected?.medianMovePct??0;
  const relativeFee=feeCost*100;
  const limited=!!(gain<relativeFee*2 || (headroom!==null && headroom<atrRatio*.5) || trendAdx<18);
  return {available:true,long:preferred.long,short:preferred.short,preferredBars:12,preferred,segments,selected,
    direction:bias,durationType,durationBars,limited,headroomPct:headroom===null?null:round(headroom,2),atrPct:round(atrRatio,2),
    sample:preferred.sample,match:preferred.match,feeRoundTripPct:round(relativeFee,3),
    note:'Сглаженная доля положительных исходов по выбранным историческим аналогам с условной комиссией и удержанием 12 свечей. Нерепрезентативная выборка, НЕ калиброванная вероятность будущей прибыли.'};
}


/* Input integrity and freshness: reject stale/gapped sets before creating signals.
   Quality is informational, never a claim about forecast success. */
function assessCandles(candles,periodMs,now=Date.now()){
  if(!Array.isArray(candles)||candles.length<265)
    return {ok:false,reason:'Недостаточно закрытых свечей для анализа.'};
  if(!Number.isFinite(periodMs)||periodMs<=0)
    return {ok:false,reason:'Некорректный интервал свечей.'};
  for(let i=0;i<candles.length;i++){
    const c=candles[i];
    if(!Number.isFinite(c.time)||![c.open,c.high,c.low,c.close,c.volume].every(Number.isFinite)||
       Math.min(c.open,c.high,c.low,c.close)<=0||c.volume<0||
       c.high<Math.max(c.open,c.close)||c.low>Math.min(c.open,c.close)||c.high<c.low||
       (i>0&&c.time<=candles[i-1].time))
      return {ok:false,reason:'Биржа вернула повреждённые или несортированные свечи.'};
  }
  const end=candles.at(-1).time+periodMs;
  const age=Math.max(0,now-end);
  if(end>now+1500)
    return {ok:false,reason:'Данные содержат незакрытую свечу или ошибку времени устройства.'};
  if(age>periodMs*3)
    return {ok:false,reason:'Котировки устарели. Проверь соединение и время устройства.'};
  const recent=candles.slice(-251);
  let missing=0,missingInSignalWindow=0;
  for(let i=1;i<recent.length;i++){
    const difference=recent[i].time-recent[i-1].time;
    if(Math.abs(difference-periodMs)>periodMs*.05){
      const skipped=Math.max(1,Math.round(difference/periodMs)-1);
      missing+=skipped;
      // EMA200/MACD and current directional judgement assume evenly spaced
      // observations. A missing bar inside their lookback cannot be ignored.
      if(i>=recent.length-201)missingInSignalWindow+=skipped;
    }
  }
  if(missingInSignalWindow>0)
    return {ok:false,reason:'В последних 200 свечах есть пропуски. Актуальная рыночная оценка недоступна.'};
  const coverage=Math.min(100,100*(recent.length-1)/(recent.length-1+missing));
  if(missing>2)
    return {ok:false,reason:'В последних 250 свечах есть существенные пропуски: анализ EMA и исходов ненадёжен.'};
  const quality=missing===0?'Полный ряд':'Есть отдельные пропуски';
  return {ok:true,quality,coverage:round(coverage,1),ageMinutes:round(age/60000,1),
    lastClosedAt:end,history:candles.length,missing};
}

/* Observed trend fatigue on the latest CLOSED candles. These are
   diagnostics for monitoring, not trigger orders or exit instructions. */
function monitorExit(t,direction,analysis={}){
 if(direction!=='LONG'&&direction!=='SHORT')
   return {state:'neutral',title:'Направление не определено',items:[],note:'Признаки завершения проверяются только после определения сценария.'};
 const flags=[];
 const isLong=direction==='LONG';
 const breached=isLong?t.close<t.e20:t.close>t.e20;
 if(breached)flags.push(isLong?'Последняя свеча закрылась ниже EMA20.':'Последняя свеча закрылась выше EMA20.');
 const fade=Number.isFinite(t.macdHistPrev)&&Number.isFinite(t.macdHistPrev2)&&
   (isLong?(t.macdHist<t.macdHistPrev&&t.macdHistPrev<t.macdHistPrev2):
   (t.macdHist>t.macdHistPrev&&t.macdHistPrev>t.macdHistPrev2));
 if(fade)flags.push('Импульс MACD ослабевает на двух последовательных закрытиях.');
 if(Number.isFinite(t.volumeRatio)&&t.volumeRatio<.7)flags.push('Текущий объём заметно ниже среднего.');
 if(isLong&&t.rsi>=72)flags.push('RSI приближается к зоне перекупленности.');
 if(!isLong&&t.rsi<=28)flags.push('RSI приближается к зоне перепроданности.');
 const level=isLong?analysis.resistance:analysis.support;
 const ahead=Number.isFinite(level)&&(isLong?level>t.close:level<t.close);
 if(ahead&&Math.abs(level-t.close)<t.atr*.8)flags.push('Ближайший технический уровень находится близко к цене.');
 const danger=breached||flags.length>=2;
 return {state:danger?'caution':flags.length?'watch':'stable',
  title:danger?'Есть признаки ослабления':flags.length?'Требуется наблюдение':'Выраженных признаков ослабления нет',
  items:flags,
  note:'Наблюдения по последней закрытой свече. Отдельный признак не доказывает разворот и не задаёт момент продажи.'};
}

/* Deep analysis: a transparent, conditional scenario based only on closed candles.
   Exit zones are descriptive projections relative to the last close, NOT verified
   optimal exits and NOT personal trade advice. Never uses an exchange account. */
function deepAnalysis(candles,analysis,forecast,intervalMinutes,feePct=.055,displayState='wait'){
  const valid=(n)=>typeof n==='number'&&Number.isFinite(n);
  if(!Array.isArray(candles)||candles.length<265||!analysis?.indicators||!forecast?.available)
    return {available:false,reason:'Недостаточно закрытых свечей или исторических аналогов.'};
  const t=analysis.indicators,close=t.close;
  if(!valid(close)||close<=0||!valid(t.atr)||t.atr<=0)return {available:false,reason:'Невозможно рассчитать уровень по текущей волатильности.'};
  const direction=displayState.includes('long')?'LONG':displayState.includes('short')?'SHORT':'WAIT';
  const confirmed=direction!=='WAIT'&&analysis.direction===direction&&!displayState.includes('soft');
  const tentative=direction!=='WAIT'&&!confirmed;
  const bars=forecast.durationBars||12;
  const times=[3,12,36].map(h=>{
    const item=forecast.segments?.find(x=>x.bars===h);
    return {bars:h,available:!!item?.available,sample:item?.sample??0,long:item?.long??null,short:item?.short??null,
      medianMovePct:item?.medianMovePct??null,medianLongPct:item?.medianLongPct??null,medianShortPct:item?.medianShortPct??null,
      intervalLong:item?.intervalLong??null,intervalShort:item?.intervalShort??null};
  });
  const score=Math.abs(analysis.score||0),adx=t.adx||0;
  const vol=t.volumeRatio||0;
  // An already-broken resistance/support is behind price; it does not cap the
  // forward move. In that case future headroom is unknown, not zero.
  const headroom=direction==='LONG'&&analysis.resistance>close?100*(analysis.resistance-close)/close:
    direction==='SHORT'&&analysis.support<close?100*(close-analysis.support)/close:null;
  const atrPct=100*t.atr/close;
  const expectedPct=forecast.selected?.medianMovePct??0;
  // Absolute movement is not the same as a profitable move in our direction.
  // A net losing historical median must NEVER produce a directional exit zone.
  const netMedianPct=direction==='LONG'?forecast.selected?.medianLongPct:
    direction==='SHORT'?forecast.selected?.medianShortPct:null;
  const negativeDirectionalMedian=valid(netMedianPct)&&netMedianPct<=0;
  const feeRoundTripPct=Math.max(0,Number(feePct)||0)*2;
  const strong=adx>=27&&score>=5&&vol>=.9;
  const weak=adx<21||vol<.65||forecast.limited;
  const strength=strong?'Выраженный тренд':weak?'Слабое / нестабильное':'Умеренное движение';
  const movement=bars===3?'Короткий импульс':bars===36?'Продолжительное движение':'Среднесрочное движение';
  const minBars=Math.max(1,Math.round(bars*.65));
  const maxBars=Math.max(minBars+1,Math.round(bars*1.35));
  const nearLevel=valid(headroom)&&headroom<Math.max(atrPct*.75,feeRoundTripPct*2);
  const highVol=atrPct>=5;
  const overheated=(direction==='LONG'&&t.rsi>=75)||(direction==='SHORT'&&t.rsi<=25);
  const limited=forecast.limited||nearLevel||highVol||overheated;
  const reasons=[];
  if(adx>=27)reasons.push('ADX указывает на выраженный направленный рынок.');
  else if(adx<21)reasons.push('ADX указывает на слабый тренд или боковое движение.');
  else reasons.push('ADX показывает умеренно выраженное движение.');
  reasons.push(vol>=1.2?'Текущий объём выше среднего.':vol<.8?'Объём ниже среднего — движение может быстро ослабнуть.':'Объём близок к среднему.');
  if(nearLevel)reasons.push('Ближайший технический уровень ограничивает запас движения.');
  if(highVol)reasons.push('Высокая волатильность увеличивает риск резкого отката.');
  if(overheated)reasons.push('RSI в экстремальной зоне — повышен риск резкого разворота.');
  if(tentative)reasons.push('Текущий сценарий предварительный: вход не подтверждён фильтрами.');
  if(direction==='WAIT')reasons.push('Сигналы противоречат друг другу или условия входа недостаточны.');
  const preferred=forecast.selected||forecast.preferred;
  const nearestLevel=direction==='LONG'?analysis.resistance:direction==='SHORT'?analysis.support:null;
  const exitDistanceFloor=Math.max(feeRoundTripPct*1.5,0.04);
  const expected=valid(expectedPct)?expectedPct:0;
  let dEarly=Math.max(atrPct*.55,Math.min(expected*.40,atrPct*.85));
  let dMid=Math.max(dEarly*1.25,Math.min(expected*.85,atrPct*1.8));
  let dExtended=Math.max(dMid*1.18,Math.min(expected*1.40,atrPct*2.8));
  const cap=valid(headroom)&&headroom>0?headroom*.94:null;
  if(cap!==null){dEarly=Math.min(dEarly,cap*.75);dMid=Math.min(dMid,cap);dExtended=Math.min(dExtended,cap);}
  // Bound targets by the direction-specific historic median, not merely the
  // median ABSOLUTE movement (which includes moves against the position).
  if(valid(netMedianPct)&&netMedianPct>0){
    const directionalGross=netMedianPct+feeRoundTripPct;
    dMid=Math.min(dMid,directionalGross);
    dEarly=Math.min(dEarly,dMid*.75);
    dExtended=Math.min(dExtended,Math.max(dMid,directionalGross*1.25));
  }
  const exitAvailable=direction!=='WAIT'&&!negativeDirectionalMedian&&!highVol&&!overheated&&
    valid(forecast.selected?.medianMovePct)&&forecast.selected.medianMovePct>0&&
    (forecast.preferred?.sample??forecast.sample??0)>=12&&valid(dMid)&&dMid>exitDistanceFloor&&dMid-dEarly>Math.max(feeRoundTripPct*.12,.008);
  const signed=pct=>close*(1+(direction==='SHORT'?-1:1)*pct/100);
  let exit=null;
  if(exitAvailable){
    const zoneLowPct=Math.max(dEarly,Math.min(dMid*.85,dMid-feeRoundTripPct*.25));
    const zoneHighPct=dMid;
    const z1=signed(zoneLowPct),z2=signed(zoneHighPct);
    exit={early:signed(dEarly),zoneLow:Math.min(z1,z2),zoneHigh:Math.max(z1,z2),
      extended:dExtended>dMid*1.05?signed(dExtended):null,
      level:valid(nearestLevel)?nearestLevel:null,
      earlyPct:round(dEarly,3),zonePct:round(dMid,3),
      extendedPct:round(dExtended,3),
      afterFeePct:round(dMid-feeRoundTripPct,3),
      baseline:close,
      note:tentative?'Условные уровни наблюдения: направление ещё не подтверждено.':'Расчётные зоны наблюдения от последней закрытой свечи; оптимальность не доказана.'};
  }
  const monitor=monitorExit(t,direction,analysis);
  const reversal=direction==='LONG'?
   ['Закрытие свечи ниже EMA 20 и ослабление MACD.', 'Снижение объёма при обновлении максимума.', 'Подход к сопротивлению или RSI выше 72.']:
   direction==='SHORT'?
   ['Закрытие свечи выше EMA 20 и усиление MACD.', 'Снижение объёма при обновлении минимума.', 'Подход к поддержке или RSI ниже 28.']:
   ['Дождаться согласованного тренда EMA, MACD и старшего интервала.', 'Проверить ADX и объём перед оценкой продолжения.'];
  return {available:true,direction,confirmed,tentative,limited,strength,movement,
    bars,minBars,maxBars,intervalMinutes,expectedPct:round(expectedPct,2),atrPct:round(atrPct,2),
    feeRoundTripPct:round(feeRoundTripPct,3),headroomPct:valid(headroom)?round(headroom,2):null,
    sample:forecast.sample,medianDirectionalNetPct:valid(netMedianPct)?round(netMedianPct,3):null,
    segments:times,exit,exitReason:direction==='WAIT'?'Нет подтверждённого направления — ценовые цели не рассчитаны.':
      highVol?'Слишком высокая волатильность для обоснованной зоны выхода.':
      overheated?'RSI в экстремальной зоне: момент выхода нельзя оценить надёжно.':
      negativeDirectionalMedian?'Историческая медиана в выбранном направлении после комиссии отрицательна: зона выхода не обоснована.':
      (forecast.preferred?.sample??forecast.sample??0)<12?'Недостаточно разнесённых исторических примеров для ценовой зоны.':
      !valid(forecast.selected?.medianMovePct)?'Недостаточно исторической оценки амплитуды движения.':
      'Потенциал у ближайшего уровня слишком мал относительно комиссии и колебаний.',
    reasons,reversal,monitor,baseline:close,updatedAt:candles[candles.length-1].time};
}

return {ema,sma,rsi,atr,adx,indicators,evaluate,outlook,deepAnalysis,assessCandles,monitorExit,sampleInterval,marketCadence,round,clamp};
});
