/* Crypto Vision Black 24.0 — analytical terminal with immutable manual session snapshots. */
(()=>{'use strict';
const C=window.CVCore,$=id=>document.getElementById(id),fmt=(n,d=4)=>Number.isFinite(Number(n))?Number(n).toLocaleString('ru-RU',{maximumFractionDigits:d}):'—';
const price=n=>Number.isFinite(n)?fmt(n,n<1?7:n<100?5:2):'—';
const pct=n=>Number.isFinite(n)?fmt(n,2)+'%':'—';
const DEFAULT={source:'bybit',symbol:'BTCUSDT',interval:'15',feePct:.055,autoRefresh:0};
const MARKET_CANDLES=960; // more historical analogues; Bybit and Binance support <= 1000
const marketCache=new Map();
// Pacing across the overview and scanner avoids bursts of public API calls.
let nextRequestAt=0;
async function paceMarketRequest(){
 const now=Date.now(),delay=Math.max(0,nextRequestAt-now);
 nextRequestAt=Math.max(now,nextRequestAt)+170;
 if(delay)await new Promise(resolve=>setTimeout(resolve,delay));
}
function clearMarketCache(){marketCache.clear();}
function sampleQuality(n){return n>=28?'Шире выборка':n>=16?'Умеренная выборка':'Малая выборка';}

const safeParse=(key,otherwise)=>{try{return JSON.parse(localStorage.getItem(key))??otherwise;}catch{return otherwise;}};
const settings={...DEFAULT,...safeParse('cv-settings-v2',{})};
if(!['bybit','binance'].includes(settings.source))settings.source='bybit';
if(![0,60,120,300].includes(Number(settings.autoRefresh)))settings.autoRefresh=0;
if(!Number.isFinite(Number(settings.feePct)))settings.feePct=DEFAULT.feePct;
settings.feePct=C.clamp(Number(settings.feePct),0,1);
let current=null,loading=false,reloadRequested=false,refreshTimer=null,chartSelection=null,toastTimer=null,resizeTimer=null,positionInterval=null;
function notify(message){const node=$('toast');node.textContent=message;node.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.classList.remove('show'),3300);}
function persist(){try{localStorage.setItem('cv-settings-v2',JSON.stringify(settings));}catch{}}
function updateFreshness(){
 const el=$('freshnessText');if(!el)return;
 if(!current){el.textContent='Свеча не подтверждена';el.className='freshness-readout unavailable';return;}
 const last=current.candles.at(-1),period=duration(current.interval),closedAt=last.time+period;
 const elapsed=Math.max(0,Date.now()-closedAt),mins=Math.floor(elapsed/60000);
 const age=mins<1?'меньше минуты':mins<60?`${mins} мин`:mins<1440?`${Math.floor(mins/60)} ч ${mins%60} мин`:`${Math.floor(mins/1440)} дн`;
 el.textContent=`Последняя свеча · ${age} назад`;
 el.className='freshness-readout'+(elapsed>period*1.5?' aging':'');
 el.title=`Закрытие: ${new Date(closedAt).toLocaleString('ru-RU')} · Не текущая цена биржи`;
}
function setStatus(message,kind=''){const node=$('netStatus');node.className='status-pill '+kind;node.querySelector('span').textContent=message;}
function localBrowserFile(){return location.protocol==='file:'||location.protocol==='content:'||location.origin==='null';}
function errorMsg(message,opts={}){
 const banner=$('errorBanner');banner.replaceChildren();banner.classList.remove('hidden');
 const headline=document.createElement('p');headline.className='connection-message';headline.textContent=message;banner.append(headline);
 if(!opts.network)return;
 const info=document.createElement('p');info.className='connection-explanation';
 info.textContent=localBrowserFile() && !window.CryptoVisionAndroid?.requestMarket ?
  'Файл открыт непосредственно из загрузок. Chrome может запретить чтение API биржи (CORS), даже при рабочем интернете. Это ограничение локального HTML, а не ошибка анализа.' :
  window.CryptoVisionAndroid?.requestMarket?'Работает сетевой модуль Android. Проверьте доступность API в вашей сети; при ограничении биржи выберите другой источник вручную.':'Биржа или соединение может быть недоступно. Попробуйте повторить запрос либо вручную выбрать другой источник.';
 banner.append(info);
 const actions=document.createElement('div');actions.className='connection-actions';
 const retry=document.createElement('button');retry.type='button';retry.className='connection-action primary';retry.textContent='Повторить запрос';
 retry.addEventListener('click',()=>{clearMarketCache();load();});actions.append(retry);
 if(settings.source==='bybit'){
  const alt=document.createElement('button');alt.type='button';alt.className='connection-action';alt.textContent='Попробовать Binance Spot';
  alt.addEventListener('click',()=>{$('source').value='binance';$('source').dispatchEvent(new Event('change'));});actions.append(alt);
 }else{
  const alt=document.createElement('button');alt.type='button';alt.className='connection-action';alt.textContent='Вернуться к Bybit';
  alt.addEventListener('click',()=>{$('source').value='bybit';$('source').dispatchEvent(new Event('change'));});actions.append(alt);
 }
 banner.append(actions);
 const sourceText=document.createElement('small');sourceText.className='connection-footnote';
 sourceText.textContent='Binance Spot и Bybit perpetual — разные рынки. Переключение только по вашему выбору.';
 banner.append(sourceText);
}
function noError(){$('errorBanner').classList.add('hidden');$('errorBanner').replaceChildren();}
function domText(id,value){$(id).textContent=value;}
function clearNoData(message='Котировки недоступны'){
 domText('dataIntegrity','Нет подтверждённого ряда');domText('fullIntegrity','Нет данных');domText('fullSampleQuality','Нет оценки');
 clearFullAnalysis(message);
 current=null;updateFreshness();if($('positionMonitor'))renderPositionMonitor();const pending=/Обновление|Загрузка/i.test(message);domText('signalTag',pending?'ОБНОВЛЕНИЕ':'НЕТ ДАННЫХ');$('signalTag').className='signal-tag '+(pending?'loading':'wait');domText('heroVerification',pending?'Получаем закрытые свечи':'Нет подтверждённых данных');$('signalTitle').className='signal-title '+(pending?'loading':'wait');domText('signalTitle',message);domText('signalDesc',pending?'Проверяем последние закрытые свечи и историю.':'Анализ без закрытых свечей невозможен.');domText('priceValue','—');
 ['readoutOpen','readoutHigh','readoutLow','readoutClose','readoutTime','s-rsi','s-adx','s-atr','s-volume','longChance','shortChance','durationLabel','durationMove','durationFee','durationRoom','durationHorizon'].forEach(id=>domText(id,'—'));
 $('longChanceBar').style.width='0';$('shortChanceBar').style.width='0';$('longCard').classList.remove('favored');$('shortCard').classList.remove('favored');domText('modelSamples','Нет оценки');domText('evidenceLong','—');domText('evidenceShort','—');domText('evidenceHint','Нет данных');domText('durationConclusion',pending?'Обновляем рыночные данные.':'Проверь подключение.');domText('lastUpdate','Данные не обновлены');domText('chartSub','Нет подтверждённых котировок');domText('s-rsi-label','Нет данных');domText('s-adx-label','Нет данных');domText('reasonList','—');domText('warningList','—');domText('technicalTable','—');domText('patternList','—');drawChart();
}
function activate(tab){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+tab));document.querySelectorAll('.tab').forEach(t=>{const active=t.dataset.tab===tab;t.classList.toggle('active',active);t.setAttribute('aria-selected',String(active));});if(tab==='overview')requestAnimationFrame(drawChart);window.scrollTo({top:0,behavior:'instant'});}
document.querySelectorAll('.tab').forEach(t=>{
 t.addEventListener('click',()=>activate(t.dataset.tab));
 t.addEventListener('keydown',e=>{
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
  e.preventDefault();const tabs=[...document.querySelectorAll('.tab')];
  const ix=tabs.indexOf(t),next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(ix+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
  tabs[next].focus();activate(tabs[next].dataset.tab);
 });
});
function dataLabel(){domText('dataSourceLabel',(settings.source==='bybit'?'Bybit USDT perpetual · публичные данные':'Binance Spot · публичные данные')+(window.CryptoVisionAndroid?.requestMarket?' · Android':''));}
function syncMarketLabels(){
 const interval=$('interval');
 const tf=interval.selectedOptions[0]?.textContent||'—';
 domText('heroInterval',tf);
 domText('fullSource',(settings.source==='bybit'?'Bybit · perpetual':'Binance · spot')+' · '+tf);
 domText('chartTitle',$('symbol').value.replace('USDT',' / USDT')+' · График');
 domText('fullAssetName',$('symbol').value.replace('USDT',' / USDT'));
}
function bybitTf(tf){return tf;}
function binanceTf(tf){return ({'1':'1m','5':'5m','15':'15m','30':'30m','60':'1h','240':'4h','D':'1d','W':'1w'})[tf]||'15m';}
function duration(tf){return ({'1':60e3,'5':300e3,'15':900e3,'30':1800e3,'60':3600e3,'240':14400e3,'D':864e5,'W':6048e5})[tf]||900e3;}
function higherTf(tf){return ({'1':'15','5':'60','15':'60','30':'240','60':'240','240':'D','D':'W'})[tf]||'D';}
const nativeRequests=new Map();let nativeSequence=0;
window.CVMarketNative={resolve(id,success,body){const pending=nativeRequests.get(Number(id));if(!pending)return;nativeRequests.delete(Number(id));if(success){try{pending.resolve(JSON.parse(body));}catch(e){pending.reject(Error('Не удалось прочитать ответ биржи.'));}}else pending.reject(Error(String(body).slice(0,200)));}};
async function nativeGetJson(url,signal){const id=++nativeSequence;return new Promise((resolve,reject)=>{if(signal?.aborted){reject(Error('Запрос отменён'));return;}const cancel=()=>{nativeRequests.delete(id);signal?.removeEventListener('abort',cancel);reject(Error('Истекло время ожидания API Android (30 секунд).'));};signal?.addEventListener('abort',cancel,{once:true});nativeRequests.set(id,{resolve:value=>{signal?.removeEventListener('abort',cancel);resolve(value);},reject:error=>{signal?.removeEventListener('abort',cancel);reject(error);}});try{window.CryptoVisionAndroid.requestMarket(url,id);}catch(e){nativeRequests.delete(id);signal?.removeEventListener('abort',cancel);reject(Error('Сетевой модуль Android недоступен.'));}});}
async function getJson(url,signal){
 if(window.CryptoVisionAndroid?.requestMarket)return nativeGetJson(url,signal);
 let response;
 try{response=await fetch(url,{signal,cache:'no-store',headers:{'Accept':'application/json'}});}
 catch(e){
  if(e?.name==='AbortError')throw Error('Биржа не ответила за 12 секунд.');
  if(!navigator.onLine)throw Error('Устройство сообщает об отсутствии интернета.');
  throw Error(localBrowserFile()? 'Нет ответа API. Локальный HTML может блокироваться Chrome (CORS).' : 'Нет ответа API. Возможны CORS, сбой сети или недоступность биржи.');
 }
 if(response.status===403||response.status===451)throw Error('Биржа ограничила доступ к API (HTTP '+response.status+').');
 if(response.status===429)throw Error('Биржа ограничила частоту запросов (HTTP 429). Попробуйте позже.');
 if(!response.ok)throw Error('Биржа вернула HTTP '+response.status);
 try{return await response.json();}catch{throw Error('Биржа вернула некорректный JSON.');}
}
/* A shared short-lived request cache prevents duplicate downloads by the
   overview and 12-market scanner. Cache never persists and never caches errors. */
async function requestCandles(symbol,tf,source=settings.source,limit=MARKET_CANDLES){
  const key=[source,symbol,tf,limit].join('|'),now=Date.now();
  const existing=marketCache.get(key);
  if(existing&&now<existing.expires)return existing.promise;
  const promise=(async()=>{
    await paceMarketRequest();
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),window.CryptoVisionAndroid?.requestMarket?30000:12000);
    try{
      let raw,rows;
      if(source==='bybit'){
        const url=`https://api.bybit.com/v5/market/kline?category=linear&symbol=${encodeURIComponent(symbol)}&interval=${bybitTf(tf)}&limit=${limit}`;
        raw=await getJson(url,controller.signal);
        if(raw.retCode!==0||!Array.isArray(raw.result?.list))throw Error('Bybit: '+(raw.retMsg||'неожиданный ответ'));
        rows=raw.result.list.map(x=>({time:+x[0],open:+x[1],high:+x[2],low:+x[3],close:+x[4],volume:+x[5]}));
      }else{
        const url=`https://data-api.binance.vision/api/v3/klines?symbol=${encodeURIComponent(symbol)}&interval=${binanceTf(tf)}&limit=${limit}`;
        raw=await getJson(url,controller.signal);
        if(!Array.isArray(raw))throw Error('Binance: неожиданный ответ');
        rows=raw.map(x=>({time:+x[0],open:+x[1],high:+x[2],low:+x[3],close:+x[4],volume:+x[5]}));
      }
      const cutoff=Date.now()-1200;
      return rows.filter(c=>[c.time,c.open,c.high,c.low,c.close,c.volume].every(Number.isFinite)&&c.time+duration(tf)<=cutoff)
        .sort((a,b)=>a.time-b.time).filter((c,i,a)=>i===0||a[i-1].time!==c.time);
    }finally{clearTimeout(timer);}
  })();
  marketCache.set(key,{promise,expires:now+18000});
  // Prevent unbounded growth when switching many markets.
  if(marketCache.size>70){for(const name of [...marketCache.keys()].slice(0,15))marketCache.delete(name);}
  promise.catch(()=>{if(marketCache.get(key)?.promise===promise)marketCache.delete(key);});
  return promise;
}

async function load(){
 if(loading){reloadRequested=true;return;}
 loading=true;document.body.classList.add('is-refreshing');$('refreshBtn').setAttribute('aria-busy','true');const symbol=$('symbol').value,interval=$('interval').value,source=settings.source;
 syncMarketLabels();
 $('refreshBtn').disabled=true;noError();setStatus('Обновляем…');
 domText('chartTitle',symbol.replace('USDT',' / USDT')+' · График');chartSelection=null;
 // Do not display stale analysis for another selected pair.
 if(!current || current.symbol!==symbol || current.interval!==interval || current.source!==source){
   clearNoData('Обновление '+symbol);domText('chartSub','Загрузка закрытых свечей');
 }
 try{
  const primary=await requestCandles(symbol,interval,source,MARKET_CANDLES);
  const health=C.assessCandles(primary,duration(interval));
  if(!health.ok)throw Error(health.reason);
  let higher=null,higherError='';
  try{
    const hiTf=higherTf(interval),candles=await requestCandles(symbol,hiTf,source,680);
    const hiHealth=C.assessCandles(candles,duration(hiTf));
    if(candles.length>=600&&hiHealth.ok)higher=C.indicators(candles);
    else higherError=hiHealth.ok?'Недостаточно свечей старшего интервала для надёжной EMA200.':hiHealth.reason;
  }catch(e){higherError=e.message;}
  // A newer selection supersedes this response; avoid mixing pair and chart.
  if(!navigator.onLine)throw Error('Нет подключения к сети.');
  if(symbol!==$('symbol').value || interval!==$('interval').value || source!==settings.source){reloadRequested=true;return;}
  const analysis=C.evaluate(primary,higher),forecast=C.outlook(primary,settings.feePct);
  if(higherError)analysis.warnings.push('Старший интервал: '+higherError);
  current={symbol,interval,source,candles:primary,analysis,forecast,health,updated:Date.now(),higher:!!higher};updateFreshness();
  settings.symbol=symbol;settings.interval=interval;persist();render();renderFullAnalysis();
  setStatus('Данные получены','online');domText('lastUpdate','Обновлено · '+new Date().toLocaleTimeString('ru-RU'));domText('dataIntegrity',health.quality+' · '+fmt(health.coverage,0)+'% свечей');
  queueScanner(); 
 }catch(e){
  if(symbol===$('symbol').value && interval===$('interval').value && source===settings.source){
   clearNoData();syncMarketLabels();setStatus('Ошибка данных','offline');
   const message=String(e?.message||'Ошибка подключения');
   const network=/Нет ответа API|CORS|HTTP|Биржа не ответила|интернета|сет[ьи]|доступ|запросов|частоту/i.test(message);
   errorMsg(message+' Данные не подтверждены.',{network});
  }
 }finally{loading=false;document.body.classList.remove('is-refreshing');$('refreshBtn').disabled=false;$('refreshBtn').removeAttribute('aria-busy');if(reloadRequested){reloadRequested=false;load();}}
}
/* Presentation never overrides the underlying entry filter. A trend can be visible
   while entry is still unconfirmed, and the UI says so explicitly. */

function signalPresentation(a,f){
 const trend=a.direction!=='WAIT'?a.direction:a.bias;
 const votes=f?.available?(f.long-f.short):0;
 const hardRisk=a.warnings.some(x=>/Сопротивление близко|Поддержка близко|Цена далеко от EMA20|Высокая волатильность|Аномально низкий объём|RSI сильно/i.test(x));
 // Price indicators and analogous outcomes are different evidence sources.
 // A strong conflict must NEVER be presented as a confirmed entry signal.
 const historyOpposes=!!f?.available&&f.sample>=16&&
  ((a.direction==='LONG'&&f.short-f.long>20)||(a.direction==='SHORT'&&f.long-f.short>20));
 if(historyOpposes)return {state:'wait',conflict:true,tag:'НЕ ВХОДИТЬ · КОНФЛИКТ',title:'Сценарии противоречат',
  desc:'Трендовые индикаторы и исторические аналоги указывают в разные стороны. Вход не подтверждён.'};
 // Technical agreement and net historical advantage are distinct.
 // Do not label an entry as confirmed if the directional median after fees is
 // non-positive, even when a majority of analogous outcomes were small wins.
 const netLong=f?.preferred?.medianLongPct,netShort=f?.preferred?.medianShortPct;
 if(f?.available&&f.sample>=16&&a.direction==='LONG'&&Number.isFinite(netLong)&&netLong<=0)
  return {state:'long soft',tag:'LONG · СЛАБОЕ ПОДТВЕРЖДЕНИЕ',title:'Рост требует подтверждения',desc:'Индикаторы склоняются к LONG, но медиана исторических исходов после комиссии неположительная.'};
 if(f?.available&&f.sample>=16&&a.direction==='SHORT'&&Number.isFinite(netShort)&&netShort<=0)
  return {state:'short soft',tag:'SHORT · СЛАБОЕ ПОДТВЕРЖДЕНИЕ',title:'Снижение требует подтверждения',desc:'Индикаторы склоняются к SHORT, но медиана исторических исходов после комиссии неположительная.'};
 if(a.direction==='LONG')return {state:'long',tag:'LONG · ПОДТВЕРЖДЁН',title:'Лонг подтверждается',desc:'Фильтры синхронны. Преимущество на стороне роста, но риск сохраняется.'};
 if(a.direction==='SHORT')return {state:'short',tag:'SHORT · ПОДТВЕРЖДЁН',title:'Шорт подтверждается',desc:'Фильтры синхронны. Преимущество на стороне снижения, но риск сохраняется.'};
 const lean=trend==='LONG' || trend==='SHORT' ? trend :
   Math.abs(a.score)>=1.6 && f?.available && Math.abs(votes)>=9 && Math.sign(a.score)===Math.sign(votes) ? (a.score>0?'LONG':'SHORT') : null;
 const contradicts=f?.available&&((lean==='LONG'&&votes< -13)||(lean==='SHORT'&&votes>13));
 if(lean&&!hardRisk&&!contradicts){
  return lean==='LONG'
   ? {state:'long soft',tag:'ВОЗМОЖЕН LONG',title:'Есть шанс на рост',desc:'Рынок смещается вверх, но вход ещё не подтверждён полностью.'}
   : {state:'short soft',tag:'ВОЗМОЖЕН SHORT',title:'Есть шанс на снижение',desc:'Рынок смещается вниз, но вход ещё не подтверждён полностью.'};
 }
 return {state:'wait',tag:'НЕ ВХОДИТЬ',title:'Сценарий не подтверждён',desc:'Сигналы смешаны либо риск выше качества входа.'};
}

window.CVSignalUI={signalPresentation};
function render(){
 if(!current)return;const a=current.analysis,t=a.indicators,f=current.forecast;
 const visual=signalPresentation(a,f);
 $('signalTag').className='signal-tag '+visual.state;
 $('signalTitle').className='signal-title '+(visual.state.includes('long')?'long':visual.state.includes('short')?'short':'wait');
 domText('signalTag',visual.tag);
 domText('signalTitle',visual.title);
 domText('signalDesc',visual.desc);
 domText('heroVerification',visual.conflict?'Конфликт независимых оценок':visual.state.includes('soft')?'Предварительное направление':visual.state==='wait'?'Вход не подтверждён':'Фильтры согласованы');
 domText('heroInterval',$('interval').selectedOptions[0].textContent+' · закрытые свечи');domText('priceValue',price(a.entry));
 domText('s-rsi',fmt(t.rsi,1));domText('s-rsi-label',t.rsi>70?'Перекупленность':t.rsi<30?'Перепроданность':'Нейтрально');
 domText('s-adx',fmt(t.adx,1));domText('s-adx-label',t.adx>=25?'Тренд':'Слабый тренд');domText('s-atr',pct(t.atrPct));domText('s-volume',fmt(t.volumeRatio,2)+'×');
 const setChance=(id,bar,value)=>{domText(id,Number.isFinite(value)?fmt(value,1)+'%':'—');$(bar).style.width=Number.isFinite(value)?C.clamp(value,0,100)+'%':'0';};
 if(f?.available){
   setChance('longChance','longChanceBar',f.long);setChance('shortChance','shortChanceBar',f.short);
   domText('modelSamples',f.sample+' разнесённых аналогов · '+sampleQuality(f.sample)+' · '+f.preferredBars+' свечей');
   const intervalText=v=>v?`${fmt(v.low,1)}–${fmt(v.high,1)}%`:'Недостаточно данных';
   domText('evidenceLong',intervalText(f.preferred?.intervalLong));
   domText('evidenceShort',intervalText(f.preferred?.intervalShort));
   domText('evidenceHint',f.sample>=30?'Выборка: '+f.sample:'Небольшая выборка: '+f.sample);
   $('longCard').classList.toggle('favored',f.long>=f.short+8);$('shortCard').classList.toggle('favored',f.short>=f.long+8);
   domText('durationLabel',visual.state==='wait'?'Нет подтверждения для удержания':f.durationType);
   domText('durationHorizon',visual.state==='wait'?'—':horizonLabel(f.durationBars,current.interval));
   domText('durationMove',fmt(f.selected.medianMovePct,2)+'%');domText('durationFee',fmt(f.feeRoundTripPct,3)+'%');domText('durationRoom',f.headroomPct==null?'Нет уровня':fmt(f.headroomPct,2)+'%');
   const brief=f.limited?'Потенциал ограничен: комиссия или ближайший уровень могут поглотить движение.':f.durationBars===3?'Скорее быстрый импульс, чем устойчивый тренд.':f.durationBars===36?'Возможно продолжение в течение многих свечей.':'Умеренный горизонт; продолжение не гарантировано.';
   domText('durationConclusion',visual.conflict?'Индикаторы и аналоги расходятся: подтверждённого сценария удержания нет.':visual.state==='wait'?'Даже при высокой исторической доле прибыльных исходов фильтры вход не подтверждают.':brief);
 }else{
   setChance('longChance','longChanceBar',null);setChance('shortChance','shortChanceBar',null);
   domText('modelSamples',f?.reason||'Оценка недоступна');
   domText('evidenceLong','—');domText('evidenceShort','—');domText('evidenceHint','Данных нет');
   domText('durationLabel','—');domText('durationHorizon','—');domText('durationMove','—');domText('durationFee','—');domText('durationRoom','—');domText('durationConclusion','Нужна достаточная история свечей.');
 }
 const reasons=$('reasonList');reasons.replaceChildren();
 [...a.reasons].filter(x=>x.score!==0).sort((a,b)=>Math.abs(b.score)-Math.abs(a.score)).slice(0,4).forEach(item=>{
  const row=document.createElement('div');row.className='factor';const sign=document.createElement('span');sign.className='factor-icon '+(item.score>0?'positive':'negative');sign.textContent=item.score>0?'↑':'↓';const label=document.createElement('div');const title=document.createElement('strong'),desc=document.createElement('p');title.textContent=item.label;desc.textContent=item.description;label.append(title,desc);row.append(sign,label);reasons.append(row);
 });
 const risks=$('warningList');risks.replaceChildren();
 const list=(visual.conflict?[visual.desc,...a.warnings]:a.warnings).slice(0,4);if(!list.length){const x=document.createElement('p');x.className='muted';x.textContent='Дополнительных ограничений не найдено.';risks.append(x);}
 list.forEach(w=>{const x=document.createElement('div');x.className='riskitem';const bullet=document.createElement('i');bullet.textContent='—';const text=document.createElement('span');text.textContent=w;x.append(bullet,text);risks.append(x);});
 updateTechnical();drawChart();renderScanner();domText('chartTitle',current.symbol.replace('USDT',' / USDT')+' · График');
}
function horizonLabel(bars,tf){const ms=duration(tf)*bars;const mins=ms/60000;
 if(mins<60)return Math.round(mins)+' мин';if(mins<1440)return fmt(mins/60,1)+' ч';return fmt(mins/1440,1)+' дн';
}
function updateTechnical(){if(!current)return;const t=current.analysis.indicators;const rows=[['EMA 20',price(t.e20)],['EMA 50',price(t.e50)],['EMA 200',price(t.e200)],['RSI 14',fmt(t.rsi,2)],['MACD histogram',fmt(t.macdHist,6)],['ADX 14',fmt(t.adx,2)],['DI+ / DI−',fmt(t.diPlus,1)+' / '+fmt(t.diMinus,1)],['ATR 14',price(t.atr)],['Bollinger 20 ±2σ',price(t.bbLower)+' / '+price(t.bbUpper)],['Поддержка (30)',price(t.low30)],['Сопротивление (30)',price(t.high30)],['Объём к среднему',fmt(t.volumeRatio,2)+'×']];const node=$('technicalTable');node.replaceChildren();rows.forEach(([label,v])=>{const row=document.createElement('div');row.className='tech-row';const l=document.createElement('span'),r=document.createElement('strong');l.textContent=label;r.textContent=v;row.append(l,r);node.append(row);});const pats=$('patternList');pats.replaceChildren();(t.patterns.length?t.patterns:['Отчётливых поглощений или пин-баров нет.']).forEach(x=>{const el=document.createElement('span');el.className='pattern-pill';el.textContent=x;pats.append(el);});domText('chartSub',current.symbol+' · '+$('interval').selectedOptions[0].textContent+' · '+(current.source==='bybit'?'Bybit perpetual':'Binance spot'));}
function bybitUrl(symbol){if(!/^[A-Z]{2,12}USDT$/.test(symbol))throw Error('Неверная пара');return 'https://www.bybit.com/trade/usdt/'+symbol;}
function openOfficial(){const symbol=$('symbol').value;try{const url=bybitUrl(symbol);if(window.CryptoVisionAndroid?.openBybit){window.CryptoVisionAndroid.openBybit(symbol);return;}window.open(url,'_blank','noopener,noreferrer');}catch(e){notify('Недоступный рынок');}}
function updateChartReadout(candle,selected=false){
 const ids=['readoutOpen','readoutHigh','readoutLow','readoutClose'];
 if(!candle){ids.forEach(id=>domText(id,'—'));domText('readoutType','Последняя видимая свеча');domText('readoutTime','—');return;}
 for(const [id,key] of [['readoutOpen','open'],['readoutHigh','high'],['readoutLow','low'],['readoutClose','close']])domText(id,price(candle[key]));
 domText('readoutType',selected?'Выбранная свеча':'Последняя видимая свеча');
 domText('readoutTime',new Date(candle.time).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}));
}
function drawChart(){const can=$('priceChart');if(!can||!can.getBoundingClientRect().width)return;
 const session=current&&positionSession&&positionSession.symbol===current.symbol&&positionSession.source===current.source?positionSession:null;
 const guide=$('chartPositionGuide');if(guide){guide.hidden=!session;guide.classList.toggle('has-stop',!!session?.stopPrice);guide.classList.toggle('has-take',!!session?.takePrice);}
 const selected=chartSelection;const ctx=setupCanvas(can);const W=can.clientWidth,H=can.clientHeight,p={left:12,top:23,right:82,bottom:35},plotW=W-p.left-p.right,plotH=H-p.top-p.bottom-80;ctx.fillStyle='#080a0c';ctx.fillRect(0,0,W,H);if(!current||plotW<60){updateChartReadout(null);ctx.fillStyle='#9aacb9';ctx.font='13px system-ui';ctx.fillText('Нет рыночных данных',18,38);return;}const all=current.candles;const count=+$('candleCount').value,offset=Math.min(+$('chartOffset').value,Math.max(0,all.length-count)),end=all.length-offset,start=Math.max(0,end-count),segment=all.slice(start,end),t=current.analysis.indicators.series;if(!segment.length){updateChartReadout(null);return;}
 updateChartReadout(selected!=null&&selected>=0&&selected<segment.length?segment[selected]:segment[segment.length-1],selected!=null&&selected>=0&&selected<segment.length);
const vals=segment.flatMap((b,i)=>[b.high,b.low,t.ema20[start+i],t.ema50[start+i],t.ema200[start+i]].filter(Number.isFinite));let top=Math.max(...vals),bottom=Math.min(...vals),pad=(top-bottom)*.09||top*.01;top+=pad;bottom-=pad;const x=i=>p.left+(i+.5)*plotW/segment.length,y=v=>p.top+(top-v)/(top-bottom)*plotH;ctx.save();ctx.lineWidth=1;ctx.font='10px system-ui';for(let n=0;n<5;n++){const py=p.top+n*plotH/4;const v=top-(top-bottom)*n/4;ctx.beginPath();ctx.strokeStyle='#51576055';ctx.setLineDash([3,5]);ctx.moveTo(p.left,py);ctx.lineTo(W-p.right,py);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#9ca5ac';ctx.textAlign='left';ctx.fillText(price(v),W-p.right+7,py+4);}ctx.textAlign='center';const tickCount=W<500?3:5;for(let n=0;n<tickCount;n++){const ix=Math.min(segment.length-1,Math.round(n*(segment.length-1)/(tickCount-1)));const date=new Date(segment[ix].time);const label=current.interval==='D'?date.toLocaleDateString('ru-RU',{day:'2-digit',month:'2-digit'}):date.toLocaleDateString('ru-RU',{day:'2-digit',month:'2-digit'})+' '+date.toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'});ctx.fillStyle='#9aa5ad';ctx.fillText(label,x(ix),H-10);}ctx.save();ctx.strokeStyle='#64737b42';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(p.left,H-p.bottom-66);ctx.lineTo(W-p.right,H-p.bottom-66);ctx.stroke();ctx.restore();const maxVol=Math.max(1,...segment.map(z=>z.volume)),barWidth=Math.max(1.2,Math.min(12,plotW/segment.length*.64));segment.forEach((b,i)=>{const xx=x(i),isUp=b.close>=b.open;ctx.fillStyle=isUp?'#A6FF27':'#FF465A';ctx.strokeStyle=ctx.fillStyle;ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(xx,y(b.high));ctx.lineTo(xx,y(b.low));ctx.stroke();const openY=y(b.open),closeY=y(b.close);ctx.fillRect(xx-barWidth/2,Math.min(openY,closeY),barWidth,Math.max(Math.abs(closeY-openY),1.1));ctx.globalAlpha=.5;const vH=b.volume/maxVol*50;ctx.fillRect(xx-barWidth/2,H-p.bottom-13-vH,barWidth,vH);ctx.globalAlpha=1;});function line(arr,color){ctx.beginPath();ctx.lineWidth=1.65;ctx.strokeStyle=color;let begun=false;segment.forEach((_,i)=>{const v=arr[start+i];if(!Number.isFinite(v))return;const yy=y(v);if(!begun){ctx.moveTo(x(i),yy);begun=true;}else ctx.lineTo(x(i),yy);});ctx.stroke();}line(t.ema200,'#8997a4');line(t.ema50,'#596a77');line(t.ema20,'#9fc8d5');
// Manual scenario overlays never alter the chart scale or submit orders.
if(session){
 const markers=[
  {value:session.entry,color:'#c8d4e2',name:'Вход',dash:[5,4]},
  {value:window.CVTradeMath.breakEven(session.entry,session.side,settings.feePct),color:'#f8d46d',name:'Б/У',dash:[3,4]},
  {value:session.stopPrice,color:'#ff6879',name:'Stop',dash:[2,5]},
  {value:session.takePrice,color:'#a6ff27',name:'Take',dash:[2,5]}
 ].filter(m=>Number.isFinite(m.value)&&m.value>0&&m.value>=bottom&&m.value<=top);
 markers.forEach((m,i)=>{
  const yy=y(m.value);ctx.save();ctx.beginPath();ctx.setLineDash(m.dash);ctx.lineWidth=1.1;
  ctx.strokeStyle=m.color;ctx.moveTo(p.left,yy);ctx.lineTo(W-p.right,yy);ctx.stroke();ctx.setLineDash([]);
  ctx.fillStyle=m.color;ctx.textAlign='left';ctx.font='600 9px system-ui';
  ctx.fillText(m.name,p.left+5,Math.max(p.top+8,Math.min(p.top+plotH-5,yy-5)));
  ctx.restore();
 });
}

// UI-only last-close guide: not a forecast, and follows the currently visible segment.
const lastVisible=segment[segment.length-1];
if(lastVisible){
 const closeY=y(lastVisible.close),closeLabel=price(lastVisible.close);
 ctx.save();ctx.setLineDash([4,5]);ctx.lineWidth=.85;ctx.strokeStyle='#a9b5bb73';
 ctx.beginPath();ctx.moveTo(p.left,closeY);ctx.lineTo(W-p.right,closeY);ctx.stroke();ctx.setLineDash([]);
 ctx.font='600 10px system-ui';ctx.textAlign='left';
 const textWidth=Math.min(p.right-10,ctx.measureText(closeLabel).width+14);
 const labelY=Math.max(p.top+11,Math.min(p.top+plotH-11,closeY));
 ctx.fillStyle='#242b31';ctx.fillRect(W-p.right+2,labelY-11,textWidth,22);
 ctx.fillStyle='#f0f3f5';ctx.fillText(closeLabel,W-p.right+9,labelY+3.5);
 ctx.restore();
}
if(selected!=null&&selected>=0&&selected<segment.length){const idx=selected,xx=x(idx);ctx.beginPath();ctx.strokeStyle='#e2e9f36e';ctx.moveTo(xx,p.top);ctx.lineTo(xx,p.top+plotH);ctx.stroke();const b=segment[idx];domText('chartTooltip',`${new Date(b.time).toLocaleString('ru-RU')}\nO: ${price(b.open)}   H: ${price(b.high)}\nL: ${price(b.low)}   C: ${price(b.close)}\nV: ${fmt(b.volume,2)}`);$('chartTooltip').classList.remove('hidden');}else $('chartTooltip').classList.add('hidden');ctx.restore();can._chartMeta={start,end,count:segment.length,left:p.left,right:p.right,width:plotW};}
function setupCanvas(can){const rect=can.getBoundingClientRect(),ratio=Math.min(window.devicePixelRatio||1,2);can.width=Math.max(1,Math.round(rect.width*ratio));can.height=Math.max(1,Math.round(rect.height*ratio));const ctx=can.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);return ctx;}
function chartPointer(e){const can=$('priceChart'),meta=can._chartMeta;if(!meta)return;const rect=can.getBoundingClientRect(),xx=e.clientX-rect.left;chartSelection=C.clamp(Math.floor((xx-meta.left)/meta.width*meta.count),0,meta.count-1);drawChart();}
$('priceChart').addEventListener('pointermove',chartPointer);$('priceChart').addEventListener('pointerdown',chartPointer);$('priceChart').addEventListener('pointerleave',()=>{chartSelection=null;drawChart();});
$('priceChart').addEventListener('keydown',e=>{
 const meta=$('priceChart')._chartMeta;if(!meta)return;
 if(!['ArrowLeft','ArrowRight','Home','End','Escape'].includes(e.key))return;
 e.preventDefault();
 if(e.key==='Escape'){chartSelection=null;}
 else if(e.key==='Home')chartSelection=0;
 else if(e.key==='End')chartSelection=meta.count-1;
 else chartSelection=C.clamp((chartSelection??meta.count-1)+(e.key==='ArrowLeft'?-1:1),0,meta.count-1);
 drawChart();
});
$('chartReset').addEventListener('click',()=>{
 $('candleCount').value='56';$('chartOffset').value='0';
 domText('candleCountLabel','56');domText('chartOffsetLabel','0');chartSelection=null;drawChart();
 notify('Вид графика восстановлен');
});
['candleCount','chartOffset'].forEach(id=>$(id).addEventListener('input',()=>{domText('candleCountLabel',$('candleCount').value);domText('chartOffsetLabel',$('chartOffset').value);chartSelection=null;drawChart();}));
function setupRefresh(){clearInterval(refreshTimer);if(settings.autoRefresh>0)refreshTimer=setInterval(()=>{if(!document.hidden&&navigator.onLine){load();}},settings.autoRefresh*1000);}
const picker={type:null,returnFocus:null,closing:null};
function syncPickerLabels(){
 domText('symbolPickerValue',$('symbol').selectedOptions[0]?.textContent||'Монета');
 domText('fullAssetName',$('symbol').selectedOptions[0]?.textContent||'Монета');
 domText('intervalPickerValue',$('interval').selectedOptions[0]?.textContent||'Интервал');
}
function populatePicker(query=''){
 const type=picker.type;if(!type)return;const select=$(type),list=$('pickerOptions');list.replaceChildren();
 const search=query.trim().toLocaleLowerCase('ru-RU');let count=0;
 for(const option of [...select.options]){
  if(search&&!option.textContent.toLocaleLowerCase('ru-RU').includes(search)&&!option.value.toLocaleLowerCase('ru-RU').includes(search))continue;
  count++;const el=document.createElement('button');el.type='button';el.className='picker-option'+(option.value===select.value?' selected':'');el.setAttribute('role','option');el.setAttribute('aria-selected',String(option.value===select.value));
  const text=document.createElement('span');text.className='picker-option-text';
  if(type==='symbol'){
   const coin=document.createElement('span');coin.className='coin-mark';coin.textContent=option.value.slice(0,-4).slice(0,2);
   const names=document.createElement('span');const main=document.createElement('strong');main.textContent=option.value.slice(0,-4);const sub=document.createElement('small');sub.textContent=' / USDT';names.append(main,sub);text.append(coin,names);
  }else{const main=document.createElement('strong');main.textContent=option.textContent;const sub=document.createElement('small');sub.textContent='Таймфрейм';text.append(main,sub);}
  const indicator=document.createElement('span');indicator.className='selected-dot';indicator.textContent=option.value===select.value?'✓':'';
  el.append(text,indicator);el.addEventListener('click',()=>{const changed=select.value!==option.value;select.value=option.value;syncPickerLabels();closePicker();if(changed)select.dispatchEvent(new Event('change',{bubbles:true}));});list.append(el);
 }
 if(!count){const empty=document.createElement('p');empty.className='picker-empty';empty.textContent='Ничего не найдено';list.append(empty);}
}
function openPicker(type){
 if(!['symbol','interval'].includes(type))return;
 clearTimeout(picker.closing);picker.type=type;picker.returnFocus=document.activeElement;
 const layer=$('pickerDialog');$('pickerHeading').textContent=type==='symbol'?'Выбор криптовалюты':'Интервал анализа';
 $('pickerSearchBox').classList.toggle('hidden',type==='interval');$('pickerSearch').value='';
 $('pickerOptions').classList.toggle('interval-mode',type==='interval');
 $('pickerFootnote').textContent='Выбор автоматически обновит анализ';
 populatePicker();layer.setAttribute('aria-hidden','false');layer.classList.add('open');
 document.body.classList.add('picker-is-open');
 requestAnimationFrame(()=>{if(type==='symbol')$('pickerSearch').focus();else $('pickerClose').focus();});
}
function closePicker(){const layer=$('pickerDialog');if(!layer.classList.contains('open'))return;layer.classList.remove('open');layer.setAttribute('aria-hidden','true');document.body.classList.remove('picker-is-open');picker.type=null;const returnFocus=picker.returnFocus;picker.closing=setTimeout(()=>{if(returnFocus?.isConnected)returnFocus.focus();},190);}
function initPicker(){
 $('symbolPicker').addEventListener('click',()=>openPicker('symbol'));
 $('fullSymbolPicker').addEventListener('click',()=>openPicker('symbol'));
 $('intervalPicker').addEventListener('click',()=>openPicker('interval'));
 $('pickerClose').addEventListener('click',closePicker);
 $('pickerDialog').querySelector('[data-dismiss-picker]').addEventListener('click',closePicker);
 $('pickerSearch').addEventListener('input',e=>populatePicker(e.target.value));
 document.addEventListener('keydown',e=>{
  if(!$('pickerDialog').classList.contains('open'))return;
  if(e.key==='Escape'){e.preventDefault();closePicker();}
  if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)&&e.target!==$('pickerSearch')){
   const buttons=[...$('pickerOptions').querySelectorAll('button:not([disabled])')];
   if(buttons.length){
    e.preventDefault();const currentIndex=buttons.indexOf(document.activeElement);
    const next=e.key==='Home'?0:e.key==='End'?buttons.length-1:e.key==='ArrowDown'?Math.min(buttons.length-1,currentIndex+1):Math.max(0,currentIndex<0?buttons.length-1:currentIndex-1);
    buttons[next].focus();
   }
  }
  if(e.key==='Tab'){const items=[...$('pickerDialog').querySelectorAll('button:not([disabled]),input:not(.hidden)')].filter(x=>x.getClientRects().length);const first=items[0],last=items.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}
 });
}

/* Market-wide filter — only monitored instruments, same analysis as the chart.
   An API error is UNKNOWN, never a WAIT verdict. Never place an order. */
const scanState={filter:'LONG',results:new Map(),errors:new Map(),busy:false,runId:0,key:'',checked:0,finishedAt:0,stale:false,networkError:false};
const scannerTTL=()=>Math.min(5*60*1000,Math.max(90*1000,duration($('interval').value)*1.5));
function expireScanner(force=false){
 if(scanState.busy&&!force)return;
 scanState.runId++;scanState.results.clear();scanState.errors.clear();scanState.checked=0;
 scanState.finishedAt=0;scanState.stale=true;scanState.networkError=false;renderScanner();
}

const scanSymbols=()=>[...$('symbol').options].map(x=>x.value);
const scanKey=()=>[settings.source,$('interval').value,Number(settings.feePct).toFixed(4)].join(':');
const scanDirection=visual=>visual.state.includes('long')?'LONG':visual.state.includes('short')?'SHORT':'WAIT';
function renderScanner(){
 const all=[...scanState.results.values()];
 for(const [direction,id] of [['LONG','longScanCount'],['SHORT','shortScanCount'],['WAIT','waitScanCount']])domText(id,String(all.filter(x=>x.direction===direction).length));
 const options=[...document.querySelectorAll('[data-scan-filter]')];
 options.forEach(button=>{const active=button.dataset.scanFilter===scanState.filter;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));});
 const list=$('scanResults');list.replaceChildren();
 $('scanProgress').style.width=(scanState.checked/Math.max(scanSymbols().length,1)*100).toFixed(1)+'%';
 const filtered=all.filter(x=>x.direction===scanState.filter).sort((a,b)=>Number(b.confirmed)-Number(a.confirmed)||(b.margin-a.margin));
 if(!filtered.length){
  const msg=document.createElement('div');msg.className='scan-empty';
  const heading=document.createElement('strong');heading.className='scan-empty-heading';
  heading.textContent=scanState.busy?'Сканирование рынка':scanState.networkError?'Источник котировок недоступен':all.length===0?'Нет проверенных результатов':'Совпадений не найдено';
  const sub=document.createElement('span');sub.className='scan-empty-body';
  sub.textContent=scanState.busy?'Монеты будут появляться по мере получения котировок.':scanState.networkError?'Проверь подключение или выбери другую биржу в параметрах.':all.length===0?
   'Проверь соединение и попробуй обновить сканер.':`Сейчас нет монет с оценкой «${scanState.filter==='WAIT'?'НЕ ВХОДИТЬ':scanState.filter}».`;
  msg.append(heading,sub);list.append(msg);
 }else filtered.forEach(item=>{
  const btn=document.createElement('button');btn.type='button';btn.className='scan-row'+($('symbol').value===item.symbol?' selected':'');btn.dataset.direction=item.direction;
  btn.setAttribute('aria-label',`${item.symbol.slice(0,-4)} — ${item.confirmed?'подтверждён':item.direction==='WAIT'?'без входа':'предварительный'} ${item.direction}. Открыть график`);
  const coin=document.createElement('div');coin.className='scan-coin';
  const icon=document.createElement('span');icon.className='scan-avatar';icon.textContent=item.symbol.slice(0,2);
  const name=document.createElement('div');name.className='scan-identity';
  const strong=document.createElement('strong');strong.textContent=item.symbol.slice(0,-4)+' / USDT';
  const meta=document.createElement('small');meta.textContent=item.confirmed?'Фильтры подтверждают направление':item.direction==='WAIT'?'Вход не подтверждён':'Предварительное склонение';
  name.append(strong,meta);coin.append(icon,name);
  const status=document.createElement('div');status.className='scan-outcome';const category=document.createElement('b');
  category.textContent=item.direction==='WAIT'?'НЕ ВХОДИТЬ':(item.confirmed?item.direction+' · ПОДТВЕРЖДЁН':'ВОЗМОЖЕН '+item.direction);
  const hint=document.createElement('small');hint.textContent=item.direction==='WAIT'?'Вход не подтверждён':Number.isFinite(item.chance)?`Ист. частота ${fmt(item.chance,1)}%`:'Недостаточно аналогов';
  status.append(category,hint);
  const arrow=document.createElement('span');arrow.className='scan-open';arrow.textContent='›';arrow.setAttribute('aria-hidden','true');
  btn.append(coin,status,arrow);
  btn.addEventListener('click',()=>{const select=$('symbol');if(select.value===item.symbol){$('priceChart').scrollIntoView({behavior:'smooth',block:'center'});return;}
   select.value=item.symbol;syncPickerLabels();chartSelection=null;clearNoData('Обновление '+item.symbol);load();setTimeout(()=>$('priceChart').scrollIntoView({behavior:'smooth',block:'center'}),60);});
  list.append(btn);
 });
 const total=scanSymbols().length,invalid=scanState.errors.size,checked=scanState.checked;
 if(scanState.busy){domText('scanStatus',`Проверено ${checked} из ${total} · ${invalid} недоступно`);}else if(scanState.networkError){
  domText('scanStatus','Сканирование остановлено · ошибка источника');
 }else if(scanState.finishedAt){
  domText('scanStatus',`Обновлено ${new Date(scanState.finishedAt).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'})} · ${invalid} недоступно`);
 }else domText('scanStatus',scanState.stale?'Результаты устарели · обновите сканер':scanState.networkError?'Сканирование остановлено · ошибка источника':'Ожидание сканирования');
 domText('scanScope',`${scanState.results.size} из ${total} · ${$('interval').selectedOptions[0].textContent}`);
 $('scanRefresh').disabled=scanState.busy;$('scanRefresh').setAttribute('aria-busy',String(scanState.busy));
}
async function scanSingle(symbol,tf,source,fee,runId){
 // First request is mandatory; failure is not interpreted as neutral.
 const primary=await requestCandles(symbol,tf,source,MARKET_CANDLES);
 const health=C.assessCandles(primary,duration(tf));
 if(!health.ok)throw Error(health.reason);
 if(runId!==scanState.runId)return;
 let higher=null;
 try{
  const hiTf=higherTf(tf),values=await requestCandles(symbol,hiTf,source,680);
  if(values.length>=600&&C.assessCandles(values,duration(hiTf)).ok)higher=C.indicators(values);
 }catch(e){/* Unavailable or stale HTF cannot confirm a direction. */}
 if(runId!==scanState.runId)return;
 const analysis=C.evaluate(primary,higher),forecast=C.outlook(primary,fee),visual=signalPresentation(analysis,forecast);
 const direction=scanDirection(visual),confirmed=analysis.direction===direction&&direction!=='WAIT'&&!visual.state.includes('soft');
 return {symbol,direction,confirmed,chance:forecast.available?forecast[direction==='SHORT'?'short':'long']:null,margin:Math.abs(analysis.score),
  updated:Date.now()};
}
async function scanMarket(force=false){
 const key=scanKey();
 if(!force && key===scanState.key&&(scanState.busy||(scanState.finishedAt&&Date.now()-scanState.finishedAt<scannerTTL()))){renderScanner();return;}
 // Invalidate late responses from previous settings; new scan has a new generation.
 const runId=++scanState.runId;
 scanState.key=key;scanState.results.clear();scanState.errors.clear();scanState.checked=0;scanState.busy=true;scanState.finishedAt=0;scanState.stale=false;scanState.networkError=false;renderScanner();
 const symbols=scanSymbols(),tf=$('interval').value,source=settings.source,fee=settings.feePct;
 let next=0;
 async function worker(){
  while(next<symbols.length&&scanState.runId===runId&&!scanState.networkError){
   const symbol=symbols[next++];
   try{const result=await scanSingle(symbol,tf,source,fee,runId);
    if(scanState.runId===runId&&result)scanState.results.set(symbol,result);
   }catch(e){if(scanState.runId===runId){scanState.errors.set(symbol,String(e.message||e));
     if(scanState.errors.size>=3&&scanState.results.size===0)scanState.networkError=true;
   }}
   if(scanState.runId===runId){scanState.checked++;renderScanner();}
  }
 }
 await Promise.all(Array.from({length:3},worker));
 if(scanState.runId!==runId)return;
 scanState.busy=false;scanState.finishedAt=Date.now();renderScanner();
}
function queueScanner(force=false){scanMarket(force).catch(e=>{scanState.busy=false;renderScanner();notify('Сканирование прервано: '+e.message);});}


/* Full analysis is derived from the same, latest closed candles as Overview.
   One market selection across the application; no simulated or live trades. */
function clearFullAnalysis(message='Ожидание данных'){
 for(const id of ['fullStrength','fullMovement','fullTimeRange','fullBarsRange','fullBasePrice','fullLevel','fullFee'])domText(id,'—');
 domText('fullDirectionTag','НЕТ ДАННЫХ');$('fullDirectionTag').className='full-verdict-tag wait';
 domText('fullDirectionTitle',message);domText('fullDirectionDesc','Расчёт невозможен без подтверждённых котировок.');
 domText('fullDataStatus','Нет данных');domText('fullUpdated','Данные недоступны');domText('fullTimeDesc','Нет подтверждённой оценки длительности.');
 domText('fullExitStatus','Нет зоны');domText('fullExitIntro','Уровни не рассчитываются без закрытых свечей.');
 domText('fullSummary','Дождитесь загрузки рынка или проверьте источник котировок.');domText('fullExitRule','Нет подтверждённых данных.');
 $('fullHorizons').replaceChildren();$('fullExitZones').replaceChildren();$('fullWarnings').replaceChildren();$('fullReasons').replaceChildren();
 $('fullLiveMonitor').className='live-watch neutral';domText('fullLiveStatus','Нет данных');domText('fullLiveNote','Без закрытых свечей оценить ослабление нельзя.');$('fullLiveReasons').replaceChildren();
 const e=document.createElement('div');e.className='full-empty';e.textContent='Данных пока нет.';$('fullExitZones').append(e);
}
function makeText(tag,className,value){const n=document.createElement(tag);n.className=className||'';n.textContent=value;return n;}
function displayHorizon(mins){
 if(!Number.isFinite(mins)||mins<=0)return '—';
 if(mins<60)return Math.round(mins)+' мин';
 if(mins<1440)return fmt(mins/60,mins%60===0?0:1)+' ч';
 return fmt(mins/1440,mins%1440===0?0:1)+' дн';
}
function renderFullAnalysis(){
 renderPositionMonitor();
 if(!current){clearFullAnalysis();return;}
 const a=current.analysis,f=current.forecast,visual=signalPresentation(a,f);
 const intervalMinutes=duration(current.interval)/60000;
 const d=C.deepAnalysis(current.candles,a,f,intervalMinutes,settings.feePct,visual.state);
 domText('fullAssetName',current.symbol.replace('USDT',' / USDT'));
 domText('fullUpdated','Срез: '+new Date(current.candles.at(-1).time).toLocaleString('ru-RU',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}));
 domText('fullSource',(current.source==='bybit'?'Bybit · perpetual':'Binance · spot')+' · '+$('interval').selectedOptions[0].textContent);
 domText('fullIntegrity',current.health?.quality||'Проверка недоступна');
 domText('fullSampleQuality',f.available?sampleQuality(f.sample)+' · '+f.sample+' аналогов':'Оценка недоступна');
 if(!d.available){clearFullAnalysis(d.reason);return;}
 const confirmed=d.confirmed,neutral=d.direction==='WAIT';
 $('fullDirectionTag').className='full-verdict-tag '+(neutral?'wait':d.direction==='LONG'?'long':'short');
 domText('fullDirectionTag',visual.tag);
 domText('fullDirectionTitle',neutral?'Сценарий не подтверждён':confirmed?(d.direction==='LONG'?'Преимущество у покупателей':'Преимущество у продавцов'):(d.direction==='LONG'?'Возможен рост':'Возможно снижение'));
 domText('fullDirectionDesc',neutral?'Направление недостаточно надёжно, поэтому удержание позиции не оценивается как подтверждённое.':
  confirmed?'Направление согласовано с фильтрами. Длительность и зоны выхода остаются ориентировочными.':
  'Есть предварительное склонение; фильтры входа не подтвердили его полностью.');
 domText('fullStrength',neutral?'Сигнал не согласован':d.strength);domText('fullMovement',neutral?'Направление неопределённо':d.movement);
 domText('fullDataStatus',confirmed?'Фильтры согласованы':neutral?'Вход не подтверждён':'Предварительно');
 $('fullDataStatus').className='full-data-status '+(neutral?'wait':d.direction==='LONG'?'long':'short');
 domText('fullTimeRange',neutral?'Не определено':displayHorizon(d.minBars*intervalMinutes)+' — '+displayHorizon(d.maxBars*intervalMinutes));
 domText('fullBarsRange',neutral?'—':d.minBars+'–'+d.maxBars+' свечей');
 domText('fullTimeDesc',neutral?'Исторические горизонты ниже показаны для сравнения, но направленный сценарий сейчас не подтверждён.':
  'Ориентир по '+d.movement.toLowerCase()+'; ниже показан расчётный таймер удержания, а не гарантированный срок сделки.');
 const horizontals=$('fullHorizons');horizontals.replaceChildren();
 const labels=['Быстрый','Средний','Продолжительный'];
 d.segments.forEach((seg,i)=>{
  const card=makeText('article','full-horizon'+(!neutral&&d.bars===seg.bars?' selected':''),'');
  const heading=makeText('div','full-horizon-heading','');
  heading.append(makeText('strong','',labels[i]),makeText('small','',displayHorizon(seg.bars*intervalMinutes)));
  const vals=makeText('div','full-horizon-values','');
  if(seg.available){
   const up=makeText('span','h-long',`LONG ${fmt(seg.long,1)}%`),dn=makeText('span','h-short',`SHORT ${fmt(seg.short,1)}%`);
   vals.append(up,dn);
  } else vals.append(makeText('span','h-unavailable','Мало аналогов'));
  card.append(heading,vals,makeText('small','full-horizon-sample',`История: ${seg.sample} разнесённых примеров`));
  if(seg.available){
    const ranges=makeText('div','full-horizon-uncertainty','');
    const intervalString=range=>range?fmt(range.low,1)+'–'+fmt(range.high,1)+'%':'—';
    ranges.append(makeText('span','',`Разброс частоты: L ${intervalString(seg.intervalLong)} · S ${intervalString(seg.intervalShort)}`));
    if(Number.isFinite(seg.medianLongPct)&&Number.isFinite(seg.medianShortPct))
      ranges.append(makeText('span','',`Медиана после комиссии: L ${fmt(seg.medianLongPct,2)}% · S ${fmt(seg.medianShortPct,2)}%`));
    card.append(ranges);
  }
  horizontals.append(card);
 });
 domText('fullBasePrice',price(d.baseline)+' USDT');
 domText('fullLevel',d.direction==='WAIT'?'—':d.headroomPct===null?'Не определён':price(d.direction==='LONG'?a.resistance:a.support)+' USDT');
 domText('fullFee',fmt(d.feeRoundTripPct,3)+'%');
 const zones=$('fullExitZones');zones.replaceChildren();
 if(d.exit){
  domText('fullExitStatus',confirmed?'Расчётная зона':'Предварительно');
  $('fullExitStatus').className='full-exit-state '+(confirmed?'available':'caution');
  domText('fullExitIntro',`От последней закрытой свечи ${price(d.baseline)} USDT. Ценовые уровни ориентировочны${d.tentative?', направление не подтверждено':''}.`);
  const fmtZone=x=>price(x)+' USDT';
  const entries=[
    ['РАННИЙ ОРИЕНТИР',fmtZone(d.exit.early),'Если импульс начинает угасать до основной цели.','early'],
    ['ОСНОВНАЯ ЗОНА',fmtZone(d.exit.zoneLow)+' — '+fmtZone(d.exit.zoneHigh),'Рассматривать фиксацию при признаках замедления.','primary'],
    ['РАСШИРЕННЫЙ',d.exit.extended?fmtZone(d.exit.extended):'Не определён','Только при сохранении сильного тренда и объёма.','extended']
  ];
  entries.forEach(([title,value,desc,cls])=>{const el=makeText('article','full-exit-item '+cls,'');el.append(makeText('small','',title),makeText('strong','',value),makeText('p','',desc));zones.append(el);});
 }else{
  domText('fullExitStatus','Нет обоснованной зоны');$('fullExitStatus').className='full-exit-state caution';
  domText('fullExitIntro','Нельзя считать цену последней свечи точкой входа и гарантировать оптимальный выход.');
  zones.append(makeText('div','full-empty',d.exitReason));
 }
 domText('fullExitRule', d.exit ? (d.confirmed ?
   'Рассматривать фиксацию при достижении основной зоны и признаках ослабления импульса на закрытой свече. Не требуется ждать абсолютного максимума или минимума.' :
   'Направление предварительное. Зона — сценарий для наблюдения; сначала требуется подтверждение тренда.') :
   'Неопределённые условия: нет основания для расчётной зоны выхода. Сначала дождитесь подтверждения направления.');
 const monitor=d.monitor;
 $('fullLiveMonitor').className='live-watch '+(monitor?.state||'neutral');
 domText('fullLiveStatus',monitor?.title||'Ожидание');
 domText('fullLiveNote',monitor?.note||'Наблюдения недоступны');
 const liveReasons=$('fullLiveReasons');liveReasons.replaceChildren();
 if(monitor?.items?.length)monitor.items.forEach(x=>liveReasons.append(makeText('span','live-watch-item',x)));
 else liveReasons.append(makeText('span','live-watch-empty',d.direction==='WAIT'?'Нет направленного сценария.':'Это не гарантия продолжения тренда.'));
 const warnings=$('fullWarnings');warnings.replaceChildren();
 d.reversal.forEach((x,i)=>{const el=makeText('div','full-watch-row','');el.append(makeText('span','full-watch-number',String(i+1).padStart(2,'0')),makeText('p','',x));warnings.append(el);});
 const lead=neutral?'Фильтры не дают достаточного преимущества ни LONG, ни SHORT.':
  `Преобладает ${d.direction==='LONG'?'восходящий':'нисходящий'} сценарий — ${confirmed?'направление подтверждено':'предварительно'}.`;
 const time=neutral?'Надёжно оценить продолжительность направленного движения сейчас нельзя.':
  `Расчётный горизонт: ${displayHorizon(d.minBars*intervalMinutes)} — ${displayHorizon(d.maxBars*intervalMinutes)}.`;
 const limit=d.limited?' Потенциал ограничен волатильностью или близким уровнем.':'';
 const exit=d.exit?` Основная зона наблюдения: ${price(d.exit.zoneLow)}–${price(d.exit.zoneHigh)} USDT; при замедлении импульса её следует переоценить.`:
  ' Надёжной зоны фиксации по текущим условиям нет.';
 domText('fullSummary',lead+' '+time+limit+exit);
 const reasons=$('fullReasons');reasons.replaceChildren();d.reasons.slice(0,4).forEach(r=>reasons.append(makeText('p','',r)));
}

/* Manual position monitor: tracks elapsed wall time, never submits an order. */
const POSITION_KEY='cv-position-monitor-v1';
let positionSession=null,positionSide='LONG';
const positionFields=['positionEntry','positionSize','positionLeverage','positionExit','positionStopPrice','positionTakePrice'];
function parseMoney(text){
 const v=String(text??'').trim().replace(/\s/g,'').replace(',','.');
 return v && /^\d+(?:\.\d+)?$/.test(v)?Number(v):NaN;
}
function signedMoney(n){return (n>0?'+':'')+fmt(n,2)+' USDT';}
function positionTime(ms){
 let sec=Math.max(0,Math.floor(ms/1000));
 const days=Math.floor(sec/86400);sec%=86400;
 const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=sec%60;
 return (days?days+'д ':'')+[h,m,s].map(v=>String(v).padStart(2,'0')).join(':');
}
function savePosition(){
 try{if(positionSession)localStorage.setItem(POSITION_KEY,JSON.stringify(positionSession));else localStorage.removeItem(POSITION_KEY);}catch{}
}
function loadPosition(){
 const raw=safeParse(POSITION_KEY,null);
 if(!raw||!Number.isFinite(raw.startedAt)||raw.startedAt>Date.now()+300000||raw.startedAt<946684800000||
    typeof raw.symbol!=='string'||!/^[A-Z]{2,12}USDT$/.test(raw.symbol)||
    !['LONG','SHORT'].includes(raw.side)||raw.source!=='bybit'&&raw.source!=='binance')return null;
 const s={...raw};
 if(!Number.isFinite(s.endedAt)||s.endedAt<s.startedAt)s.endedAt=null;
 if(!Number.isFinite(s.entry)||s.entry<=0||!Number.isFinite(s.notional)||s.notional<=0||
   !Number.isFinite(s.leverage)||s.leverage<1||s.leverage>125||
   !window.CVTradeMath.estimate({side:s.side,entry:s.entry,exit:s.entry,notional:s.notional,leverage:s.leverage,feePct:settings.feePct}))return null;
 for(const key of ['manualExit','stopPrice','takePrice','lockedExit']){
  if(s[key]!=null&&(!Number.isFinite(s[key])||s[key]<=0))s[key]=null;
 }
 return s;
}
function setPositionSide(side){
 // A running or paused session represents one specific directional hypothesis.
 if(positionSession){notify('Направление сессии зафиксировано. Нажми «Сброс» для новой.');return;}
 positionSide=side;
 $('positionLong').classList.toggle('active',side==='LONG');$('positionShort').classList.toggle('active',side==='SHORT');
 $('positionLong').setAttribute('aria-pressed',String(side==='LONG'));
 $('positionShort').setAttribute('aria-pressed',String(side==='SHORT'));
 if(positionSession&&positionSession.symbol===$('symbol').value&&positionSession.source===settings.source){
  positionSession.side=side;savePosition();
 }
 renderPositionMonitor();drawChart();
}
function positionValid(){
 // Once a session starts, calculations use the saved input snapshot, not the
 // controls. This also guards against out-of-band DOM changes in WebView.
 const entry=positionSession?positionSession.entry:parseMoney($('positionEntry').value);
 const notional=positionSession?positionSession.notional:parseMoney($('positionSize').value);
 const lev=positionSession?positionSession.leverage:Number($('positionLeverage').value);
 return {entry,notional,lev,ok:Number.isFinite(entry)&&entry>0&&Number.isFinite(notional)&&notional>0&&Number.isFinite(lev)&&lev>=1&&lev<=125};
}
function currentPriceForPosition(){
 if(!current||current.symbol!==$('symbol').value||current.source!==settings.source)return null;
 const q=current.candles.at(-1)?.close;
 return Number.isFinite(q)&&q>0?q:null;
}
function renderPositionMonitor(){
 const same=!!positionSession&&positionSession.symbol===$('symbol').value&&positionSession.source===settings.source;
 const other=!!positionSession&&!same;
 const active=same&&!positionSession.endedAt;
 const ended=same&&!!positionSession.endedAt;
 const locked=!!positionSession;
 for(const id of ['positionEntry','positionSize','positionLeverage'])$(id).disabled=locked;
 $('positionLong').disabled=locked;$('positionShort').disabled=locked;
 $('positionUsePrice').disabled=locked||!currentPriceForPosition();
 $('positionLockMessage').hidden=!locked;
 const now=Date.now();
 const elapsed=same?((positionSession.endedAt||now)-positionSession.startedAt):0;
 domText('positionElapsed',positionTime(elapsed));
 domText('positionTimerState',active?'Идёт отсчёт':ended?'Остановлен':other?'Сессия другого рынка':'Не запущен');
 $('positionStart').textContent=active?'Таймер запущен':ended?'Продолжить':'Запустить таймер';
 $('positionStart').disabled=active||other;
 $('positionReturn').hidden=!other;
 $('positionStop').disabled=!active;
 $('positionPair').textContent=$('symbol').value.replace('USDT',' / USDT');
 const market=currentPriceForPosition();
 const enteredExit=$('positionExit').value.trim();
 const manual=enteredExit!=='';
 const exit=manual?parseMoney(enteredExit):(ended?positionSession.lockedExit??null:market);
 const fields=positionValid();
 const validExit=Number.isFinite(exit)&&exit>0;
 const allowed=!other;
 const result=allowed&&fields.ok&&validExit?window.CVTradeMath.estimate({side:positionSession?.side||positionSide,entry:fields.entry,exit,notional:fields.notional,leverage:fields.lev,feePct:settings.feePct}):null;
 const profit=$('positionProfitCard');profit.className='position-profit '+(!result?'neutral':result.pnl>0?'positive':result.pnl<0?'negative':'neutral');
 domText('positionPnL',result?signedMoney(result.pnl):'—');
 domText('positionRoi',result?'ROI '+(result.roi>0?'+':'')+fmt(result.roi,2)+'%':'ROI —');
 domText('positionCurrentPrice',validExit&&allowed?price(exit)+' USDT':'—');
 domText('positionMargin',result?fmt(result.margin,2)+' USDT':'—');
 domText('positionFees',result?fmt(result.fees,3)+' USDT':'—');
 domText('positionPriceChange',result?(result.changePct>0?'+':'')+fmt(result.changePct,2)+'%':'—');
 const stopText=$('positionStopPrice').value.trim(),takeText=$('positionTakePrice').value.trim();
 const stop=stopText?parseMoney(stopText):null,take=takeText?parseMoney(takeText):null;
 const calcPlan=fields.ok?window.CVTradeMath.levels({side:positionSide,entry:fields.entry,notional:fields.notional,leverage:fields.lev,feePct:settings.feePct,stop,take}):null;
 domText('positionBreakEven',calcPlan?price(calcPlan.breakEven)+' USDT':'—');
 const planProvided=stopText!==''||takeText!=='';
 const invalidPlan=(stopText!==''&&(!Number.isFinite(stop)||stop<=0||calcPlan?.invalidStop))||
   (takeText!==''&&(!Number.isFinite(take)||take<=0||calcPlan?.invalidTake));
 const ratio=calcPlan?.rewardRisk;
 const riskAboveTarget=Number.isFinite(ratio)&&ratio<1;
 domText('positionPlanStatus',invalidPlan?'Проверь Stop / Take':!planProvided?'Уровни не заданы':riskAboveTarget?'Риск выше цели':Number.isFinite(ratio)?'План рассчитан':'Частичный план');
 $('positionPlanStatus').classList.toggle('risk-warning',invalidPlan||riskAboveTarget);
 $('positionPlanOutput').hidden=!planProvided||!calcPlan;
 const marginBase=calcPlan&&fields.ok?fields.notional/fields.lev:null;
 const withMargin=x=>x&&Number.isFinite(marginBase)&&marginBase>0?
  signedMoney(x.pnl)+' · '+fmt(Math.abs(x.pnl/marginBase*100),1)+'% маржи':'—';
 domText('positionRiskValue',withMargin(calcPlan?.stop));
 domText('positionRewardValue',withMargin(calcPlan?.take));
 domText('positionRRValue',Number.isFinite(calcPlan?.rewardRisk)?'1 : '+fmt(calcPlan.rewardRisk,2):'—');
 $('positionRiskValue').className=calcPlan?.stop?'negative':'';
 $('positionRewardValue').className=calcPlan?.take?'positive':'';
 $('positionRRValue').className=Number.isFinite(calcPlan?.rewardRisk)?'positive':'';
 const marginRisk=result&&result.pnl<=-result.margin;
 $('positionMessage').classList.toggle('alert',other||!fields.ok||invalidPlan||marginRisk);
 const monitorMessage=other?`Сессия ${positionSession.symbol.replace('USDT',' / USDT')} сохранена. Выбери эту монету или запусти новый таймер.`:
   !fields.ok?'Для расчёта нужны положительная цена входа и объём позиции.':
   !validExit?'Нет цены закрытой свечи. Укажи цену выхода вручную либо обнови котировки.':
   active?'Сессия активна · параметры входа зафиксированы; P&L обновляется по закрытым свечам.':
   ended?'Секундомер остановлен · снимок цены сохранён, реальная позиция не закрыта.':'Это калькулятор, не биржевая позиция.';
 domText('positionMessage',monitorMessage+(marginRisk?' Внимание: модельный убыток достигает маржи; в реальной торговле возможна ликвидация раньше.':''));
 const priceSourceNote=settings.source==='binance'?'Binance Spot — источник котировки; расчёт P&L остаётся условной моделью USDT-фьючерсов. ':'';
 domText('positionPriceSource',priceSourceNote+(manual?'Цена выхода указана вручную; это модель закрытия, не исполненная сделка. Funding, проскальзывание и ликвидация не учтены.':
  ended&&validExit?'Снимок последней закрытой свечи при остановке таймера. Котировка зафиксирована, но реальная сделка не закрыта.':
  validExit?'Расчёт по последней закрытой свече, не по онлайн-цене. Funding, проскальзывание и ликвидация не учтены.':
  'Нет подтверждённой котировки для расчёта P&L. Таймер работает независимо от рынка.'));
}
function initPositionMonitor(){
 positionSession=loadPosition();
 if(positionSession){
  positionSide=positionSession.side;
  $('positionLong').classList.toggle('active',positionSide==='LONG');
  $('positionShort').classList.toggle('active',positionSide==='SHORT');
  $('positionLong').setAttribute('aria-pressed',String(positionSide==='LONG'));
  $('positionShort').setAttribute('aria-pressed',String(positionSide==='SHORT'));
  $('positionEntry').value=String(positionSession.entry);
  $('positionSize').value=String(positionSession.notional);
  $('positionLeverage').value=String(positionSession.leverage);
  $('positionExit').value=positionSession.manualExit==null?'':String(positionSession.manualExit);
  $('positionStopPrice').value=positionSession.stopPrice==null?'':String(positionSession.stopPrice);
  $('positionTakePrice').value=positionSession.takePrice==null?'':String(positionSession.takePrice);
  if(positionSession.stopPrice!=null||positionSession.takePrice!=null)$('positionPlan').open=true;
 }
 $('positionLong').addEventListener('click',()=>setPositionSide('LONG'));
 $('positionShort').addEventListener('click',()=>setPositionSide('SHORT'));
 positionFields.forEach(id=>$(id).addEventListener(id==='positionLeverage'?'change':'input',()=>{
  if(positionSession&&positionSession.symbol===$('symbol').value&&positionSession.source===settings.source){
   // Entry, notional, leverage and side remain the launch-time snapshot.
   const x=$('positionExit').value.trim();positionSession.manualExit=x===''?null:parseMoney(x);
   const s=$('positionStopPrice').value.trim(),t=$('positionTakePrice').value.trim();
   positionSession.stopPrice=s===''?null:parseMoney(s);
   positionSession.takePrice=t===''?null:parseMoney(t);
   savePosition();
  }
  renderPositionMonitor();drawChart();
 }));
 $('positionUsePrice').addEventListener('click',()=>{
  const v=currentPriceForPosition();if(v==null){notify('Котировки недоступны. Укажи цену вручную.');return;}
  $('positionEntry').value=String(v);
  $('positionEntry').dispatchEvent(new Event('input'));
 });
 $('positionStart').addEventListener('click',()=>{
  if(positionSession&&(positionSession.symbol!==$('symbol').value||positionSession.source!==settings.source)){
   notify('Сначала вернись к сессии или сбрось её.');return;
  }
  if(positionSession&&!positionSession.endedAt)return;
  const v=positionValid();
  const mathOk=v.ok&&!!window.CVTradeMath.estimate({side:positionSide,entry:v.entry,exit:v.entry,notional:v.notional,leverage:v.lev,feePct:settings.feePct});
  if(!mathOk){notify('Проверь цену входа, номинал и плечо: расчёт должен быть конечным.');renderPositionMonitor();return;}
  const now=Date.now();
  if(positionSession?.endedAt){
   positionSession.startedAt=now-(positionSession.endedAt-positionSession.startedAt);
   positionSession.endedAt=null;
   positionSession.lockedExit=null;
  }else{
   positionSession={symbol:$('symbol').value,source:settings.source,side:positionSide,entry:v.entry,notional:v.notional,leverage:v.lev,
    manualExit:$('positionExit').value.trim()?parseMoney($('positionExit').value):null,
    stopPrice:$('positionStopPrice').value.trim()?parseMoney($('positionStopPrice').value):null,
    takePrice:$('positionTakePrice').value.trim()?parseMoney($('positionTakePrice').value):null,
    lockedExit:null,startedAt:now,endedAt:null};
  }
  savePosition();renderPositionMonitor();drawChart();
 });
 $('positionStop').addEventListener('click',()=>{
  if(positionSession&&positionSession.symbol===$('symbol').value&&positionSession.source===settings.source&&!positionSession.endedAt){
   positionSession.endedAt=Date.now();
   positionSession.lockedExit=currentPriceForPosition();
   savePosition();renderPositionMonitor();drawChart();
  }
 });
 $('positionReturn').addEventListener('click',()=>{
  if(!positionSession)return;
  if(!$('symbol').querySelector(`option[value="${positionSession.symbol}"]`))return;
  $('symbol').value=positionSession.symbol;
  syncPickerLabels();
  $('source').value=positionSession.source;
  $('source').dispatchEvent(new Event('change'));
 });
 $('positionReset').addEventListener('click',()=>{
  positionSession=null;savePosition();
  $('positionEntry').value='';$('positionExit').value='';$('positionStopPrice').value='';$('positionTakePrice').value='';$('positionPlan').open=false;$('positionSize').value='100';$('positionLeverage').value='1';positionSide='LONG';
  $('positionLong').classList.add('active');$('positionShort').classList.remove('active');
  $('positionLong').setAttribute('aria-pressed','true');$('positionShort').setAttribute('aria-pressed','false');
  renderPositionMonitor();drawChart();
 });
 renderPositionMonitor();
}

function bind(){
 settings.feePct=C.clamp(Number.isFinite(Number(settings.feePct))?Number(settings.feePct):.055,0,1);
 if(!$('symbol').querySelector(`option[value="${settings.symbol}"]`))settings.symbol='BTCUSDT';
 if(!$('interval').querySelector(`option[value="${settings.interval}"]`))settings.interval='15';
 $('symbol').value=settings.symbol;$('interval').value=settings.interval;$('source').value=settings.source;initPicker();syncPickerLabels();
 $('autoRefresh').value=String(settings.autoRefresh);$('feeSetting').value=String(settings.feePct);dataLabel();initPositionMonitor();
 $('refreshBtn').onclick=()=>{clearMarketCache();expireScanner(true);load();};$('fullGoChart').onclick=()=>{activate('overview');requestAnimationFrame(()=>$('priceChart').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'center'}));};$('chartBybitBtn').onclick=openOfficial;
 $('scanRefresh').onclick=()=>{clearMarketCache();queueScanner(true);};document.querySelectorAll('[data-scan-filter]').forEach(b=>b.addEventListener('click',()=>{scanState.filter=b.dataset.scanFilter;renderScanner();}));
 $('symbol').addEventListener('change',()=>{chartSelection=null;clearNoData('Обновление '+$('symbol').value);syncMarketLabels();load();});
 $('interval').addEventListener('change',()=>{chartSelection=null;clearNoData('Обновление интервала');syncMarketLabels();expireScanner(true);load();});
 $('source').addEventListener('change',()=>{settings.source=$('source').value;clearMarketCache();clearNoData('Обновление источника');dataLabel();syncMarketLabels();expireScanner(true);persist();load();});
 $('feeSetting').addEventListener('change',()=>{const value=+$('feeSetting').value;if(!Number.isFinite(value)||value<0||value>1){notify('Комиссия от 0 до 1%');$('feeSetting').value=settings.feePct;return;}settings.feePct=value;persist();if(current){current.forecast=C.outlook(current.candles,settings.feePct);render();renderFullAnalysis();}queueScanner();});
 $('autoRefresh').addEventListener('change',()=>{settings.autoRefresh=Number($('autoRefresh').value);persist();setupRefresh();});
 window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(drawChart,120);});
 document.addEventListener('visibilitychange',()=>{
  if(document.hidden)return;
  if(scanState.finishedAt&&Date.now()-scanState.finishedAt>scannerTTL())expireScanner();
  if(!current)return;
  const health=C.assessCandles(current.candles,duration(current.interval));
  if(!health.ok){
    clearNoData('Котировки устарели');setStatus('Требуется обновление','offline');
    errorMsg('Котировки устарели после возврата в приложение.');
    if(settings.autoRefresh){load();queueScanner();}
  }else if(settings.autoRefresh&&Date.now()-current.updated>settings.autoRefresh*1000){load();queueScanner();}
 });
 window.addEventListener('online',()=>{setStatus('Сеть доступна');load();});window.addEventListener('offline',()=>{clearMarketCache();expireScanner(true);clearNoData('Нет сети');setStatus('Нет подключения','offline');});
 if('serviceWorker' in navigator&&location.protocol==='https:'&&location.hostname!=='appassets.androidplatform.net')navigator.serviceWorker.register('./sw.js').catch(()=>{});
 setupRefresh();renderScanner();syncMarketLabels();load();
 setInterval(()=>{
  if(scanState.finishedAt&&Date.now()-scanState.finishedAt>scannerTTL())expireScanner();
  if(current){updateFreshness();const q=C.assessCandles(current.candles,duration(current.interval));if(!q.ok){clearNoData('Котировки устарели');setStatus('Требуется обновление','offline');errorMsg('Истекла актуальность свечей. Обнови данные.');}}
 },15000);
 positionInterval=setInterval(()=>{if(document.visibilityState!=='hidden')renderPositionMonitor();},1000);
}
bind();
})();
