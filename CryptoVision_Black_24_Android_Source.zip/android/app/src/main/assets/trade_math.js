/* USDT linear position monitor. Estimation only; does not place orders. */
(function(root,factory){
 const api=factory();
 if(typeof module!== 'undefined' && module.exports)module.exports=api;
 root.CVTradeMath=api;
})(typeof globalThis!== 'undefined'?globalThis:this,function(){
 'use strict';
 function breakEven(entry,side,feePct){
  if(!Number.isFinite(entry)||entry<=0||!['LONG','SHORT'].includes(side)||
     !Number.isFinite(feePct)||feePct<0||feePct>1)return null;
  const fee=feePct/100;
  return side==='LONG'?entry*(1+fee)/(1-fee):entry*(1-fee)/(1+fee);
 }
 function levels(input){
  const {side,entry,notional,leverage,feePct,stop,take}=input||{};
  const valid=(v)=>typeof v==='number'&&Number.isFinite(v)&&v>0;
  if(!valid(entry)||!valid(notional)||!valid(leverage)||!Number.isFinite(feePct)||
     !['LONG','SHORT'].includes(side)||leverage<1||leverage>125||feePct<0||feePct>1)return null;
  const stopResult=valid(stop)?estimate({side,entry,exit:stop,notional,leverage,feePct}):null;
  const takeResult=valid(take)?estimate({side,entry,exit:take,notional,leverage,feePct}):null;
  const stopValid=stopResult!==null&&stopResult.pnl<0&&((side==='LONG'&&stop<entry)||(side==='SHORT'&&stop>entry));
  const takeValid=takeResult!==null&&takeResult.pnl>0&&((side==='LONG'&&take>entry)||(side==='SHORT'&&take<entry));
  return {breakEven:breakEven(entry,side,feePct),
   stop:stopValid?stopResult:null,take:takeValid?takeResult:null,
   invalidStop:valid(stop)&&!stopValid,invalidTake:valid(take)&&!takeValid,
   rewardRisk:stopValid&&takeValid?takeResult.pnl/Math.abs(stopResult.pnl):null};
 }
 function estimate(input){
  const {side,entry,exit,notional,leverage,feePct}=input||{};
  const all=[entry,exit,notional,leverage,feePct];
  if(!['LONG','SHORT'].includes(side)||all.some(x=>typeof x!=='number'||!Number.isFinite(x))||
    entry<=0||exit<=0||notional<=0||leverage<1||leverage>125||feePct<0||feePct>1)return null;
  const qty=notional/entry;
  const gross=qty*(exit-entry)*(side==='LONG'?1:-1)||0;
  const openFee=notional*feePct/100;
  const closeFee=qty*exit*feePct/100;
  const fees=openFee+closeFee;
  const pnl=gross-fees;
  const margin=notional/leverage;
  const roi=100*pnl/margin,changePct=100*(exit/entry-1),notionalExit=qty*exit;
  // Reject overflow rather than showing misleading 0, infinity or a false ROI.
  if(![qty,gross,fees,openFee,closeFee,pnl,margin,roi,changePct,notionalExit]
       .every(Number.isFinite)||margin<=0||qty<=0)return null;
  return {qty,gross,fees,openFee,closeFee,pnl,margin,roi,changePct,notionalExit};
 }
 return {estimate,breakEven,levels};
});
