/* Versioned shell only. Market API responses are never cached by this worker. */
const CACHE='cv-black-shell-v24';
const SHELL=['./','./index.html','./styles.css','./studio.css','./core.js','./app.js','./trade_math.js','./icons/icon.svg','./manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('cv-black-')&&key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==self.location.origin)return;
 event.respondWith(fetch(request).then(response=>{
  if(response.ok&&response.type!=='opaque'){
   const copy=response.clone();event.waitUntil(caches.open(CACHE).then(cache=>cache.put(request,copy)));
  }
  return response;
 }).catch(async()=>await caches.match(request)||(request.mode==='navigate'?await caches.match('./index.html'):null)||Response.error()));
});
