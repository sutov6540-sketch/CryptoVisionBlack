package com.cryptovision.pro;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.graphics.Insets;
import android.view.WindowInsets;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.WindowManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.view.Gravity;
import java.io.InputStream;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.net.URL;
import java.net.URI;
import java.net.HttpURLConnection;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.Map;
import java.util.HashMap;

public final class MainActivity extends Activity {
    private static final String HOME = "https://appassets.androidplatform.net";
    private WebView webView;
    private WebView bybitView;
    private FrameLayout container;
    private LinearLayout bybitPanel;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(5,6,7));
        getWindow().setNavigationBarColor(Color.rgb(5,6,7));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5,6,7));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new MarketBridge(), "CryptoVisionAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !"appassets.androidplatform.net".equals(uri.getHost())) return null;
                String path = uri.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                if (path.contains("..") || path.contains("\\")) return notFound();
                try {
                    String name = path.substring(1);
                    InputStream input = getAssets().open(name);
                    String type = name.endsWith(".html") ? "text/html" : name.endsWith(".js") ? "application/javascript" : name.endsWith(".css") ? "text/css" : name.endsWith(".svg") ? "image/svg+xml" : name.endsWith(".webmanifest") ? "application/manifest+json" : "application/octet-stream";
                    Map<String,String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-cache");
                    headers.put("X-Content-Type-Options", "nosniff");
                    return new WebResourceResponse(type, "UTF-8", 200, "OK", headers, input);
                } catch (Exception e) { return notFound(); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !("https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost()));
            }
            private WebResourceResponse notFound() {
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
            }
        });
        container = new FrameLayout(this);
        // Android 15+ enforces edge-to-edge for targetSdk 35. Keep both WebViews
        // inside safe system-bar / cutout insets; otherwise header buttons may
        // be obscured by the camera cutout, status bar or gesture navigation.
        if (Build.VERSION.SDK_INT >= 35) {
            container.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return insets;
            });
        }
        container.addView(webView, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(container);
        webView.loadUrl(HOME+"/index.html");
    }
    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void openBybitSite(String symbol) {
        // Input is verified, no arbitrary URLs can be opened through the JS bridge.
        if (symbol == null || !symbol.matches("[A-Z]{2,12}USDT")) return;
        runOnUiThread(() -> {
            closeBybitSite();
            bybitPanel = new LinearLayout(this);
            bybitPanel.setOrientation(LinearLayout.VERTICAL);
            bybitPanel.setBackgroundColor(Color.rgb(5,6,7));
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setPadding(dp(15), dp(9), dp(15), dp(9));
            top.setMinimumHeight(dp(62));
            top.setBackgroundColor(Color.rgb(17,22,28));
            Button back = new Button(this);
            back.setText("← НАЗАД");
            back.setAllCaps(false);
            back.setTextSize(11);
            back.setLetterSpacing(.07f);
            back.setTextColor(Color.rgb(231,239,245));
            back.setMinHeight(dp(42));
            back.setMinWidth(dp(98));
            back.setPadding(dp(13), dp(6), dp(13), dp(6));
            GradientDrawable backSurface = new GradientDrawable();
            backSurface.setColor(Color.rgb(34,45,55));
            backSurface.setCornerRadius(dp(11));
            backSurface.setStroke(dp(1), Color.rgb(72,89,102));
            back.setBackground(backSurface);
            back.setOnClickListener(v -> closeBybitSite());
            top.addView(back, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)));
            TextView title = new TextView(this);
            title.setText("BYBIT  /  " + symbol);
            title.setGravity(Gravity.CENTER_VERTICAL);
            title.setPadding(dp(16), 0, 0, 0);
            title.setLetterSpacing(.10f);
            title.setTextColor(Color.rgb(217,230,238));
            title.setTextSize(11);
            top.addView(title, new LinearLayout.LayoutParams(0, dp(42), 1));
            bybitPanel.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            bybitView = new WebView(this);
            bybitView.setBackgroundColor(Color.rgb(5,6,7));
            WebSettings s = bybitView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            s.setJavaScriptCanOpenWindowsAutomatically(false);
            bybitView.setWebChromeClient(new WebChromeClient());
            // Separate view: bybit.com does NOT get CryptoVisionAndroid JS bridge.
            bybitView.setWebViewClient(new WebViewClient() {
                @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    String host=uri.getHost();
                    return !"https".equals(uri.getScheme()) ||
                        !("www.bybit.com".equals(host) || "bybit.com".equals(host));
                }
            });
            bybitPanel.addView(bybitView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
            container.addView(bybitPanel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            bybitView.loadUrl("https://www.bybit.com/trade/usdt/" + symbol);
        });
    }
    private void closeBybitSite() {
        if(bybitPanel!=null && container!=null) container.removeView(bybitPanel);
        bybitPanel=null;
        if(bybitView!=null) { bybitView.stopLoading(); bybitView.destroy(); bybitView=null; }
    }
    // Exchange market data is fetched on a background thread. The WebView itself
    // only reads bundled assets. This removes the local-HTML CORS issue, but it
    // cannot overcome DNS, ISP, exchange, regional or country restrictions.
    private static final class MarketHttpException extends IOException {
        final int status;
        MarketHttpException(int status) { super("HTTP " + status); this.status = status; }
    }

    private String downloadMarket(URL url) throws IOException {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(6000);
            connection.setReadTimeout(8000);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "CryptoVisionBlack/24.0 Android market-data client");
            int status = connection.getResponseCode();
            if (status != 200) throw new MarketHttpException(status);
            try (InputStream in = connection.getInputStream();
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) {
                    if (out.size() + n > 3_000_000) throw new IOException("Ответ биржи слишком большой");
                    out.write(buf, 0, n);
                }
                String body = out.toString("UTF-8").trim();
                if (!body.startsWith("{") && !body.startsWith("["))
                    throw new IOException("API вернул не JSON (возможна блокировка биржи)");
                return body;
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private boolean isAllowedMarketUrl(URL url) {
        if (!"https".equals(url.getProtocol()) || url.getPort() != -1 ||
            url.getUserInfo() != null || url.getRef() != null || url.getQuery() == null ||
            url.getQuery().length() > 250) return false;
        String h = url.getHost(), path = url.getPath(), q = url.getQuery();
        boolean bybit = ("api.bybit.com".equals(h) || "api.bytick.com".equals(h)) &&
            "/v5/market/kline".equals(path) &&
            q.matches("category=linear&symbol=[A-Z0-9]{2,15}USDT&interval=(1|5|15|30|60|240|D|W)&limit=[0-9]{1,4}");
        boolean binance = ("data-api.binance.vision".equals(h) || "api.binance.com".equals(h)) &&
            "/api/v3/klines".equals(path) &&
            q.matches("symbol=[A-Z0-9]{2,15}USDT&interval=(1m|5m|15m|30m|1h|4h|1d|1w)&limit=[0-9]{1,4}");
        if (!bybit && !binance) return false;
        int p = q.lastIndexOf("limit=");
        try { int limit = Integer.parseInt(q.substring(p + 6)); return limit >= 1 && limit <= 1000; }
        catch (Exception ignored) { return false; }
    }

    private String requestMarketWithFallback(String rawUrl) throws Exception {
        if (rawUrl == null || rawUrl.length() > 512) throw new SecurityException("Недопустимый адрес API");
        URL primary = new URL(rawUrl);
        if (!isAllowedMarketUrl(primary)) throw new SecurityException("Сетевой адрес не разрешён");
        try {
            return downloadMarket(primary);
        } catch (MarketHttpException e) {
            // Do not bypass rate limits (429) or regional access restrictions
            // (403/451) by switching the exchange host.
            if (e.status < 500) throw e;
        } catch (IOException ignored) { /* Try the same exchange's official backup. */ }
        String firstHost = primary.getHost();
        String otherHost = firstHost.endsWith("bybit.com") ? "api.bytick.com" :
                           firstHost.endsWith("bytick.com") ? "api.bybit.com" :
                           firstHost.equals("data-api.binance.vision") ? "api.binance.com" :
                           "data-api.binance.vision";
        URI uri = primary.toURI();
        URL backup = new URI(uri.getScheme(), null, otherHost, -1,
                             uri.getPath(), uri.getQuery(), null).toURL();
        if (!isAllowedMarketUrl(backup)) throw new SecurityException("Резервный адрес не разрешён");
        try { return downloadMarket(backup); }
        catch (MarketHttpException e) { throw new IOException("Недоступен API " + firstHost + " / " + otherHost + " (HTTP " + e.status + ")"); }
        catch (IOException e) { throw new IOException("Нет соединения с " + firstHost + " и " + otherHost + ": " + e.getClass().getSimpleName()); }
    }

    public class MarketBridge {
        @JavascriptInterface public void openBybit(String symbol) { openBybitSite(symbol); }
        @JavascriptInterface public void requestMarket(String rawUrl, int requestId) {
            if (requestId <= 0) return;
            new Thread(() -> {
                boolean success = false;
                String result;
                try {
                    result = requestMarketWithFallback(rawUrl);
                    success = true;
                } catch (MarketHttpException e) {
                    result = e.status == 403 || e.status == 451 ?
                        "API биржи ограничил доступ (HTTP " + e.status + "). Попробуйте другой источник вручную." :
                        e.status == 429 ? "API ограничил частоту запросов (HTTP 429)." :
                        "Биржа вернула HTTP " + e.status;
                } catch (Exception e) {
                    result = e.getMessage() == null ? "Не удалось получить рыночные данные" : e.getMessage();
                }
                final String javascript = "window.CVMarketNative&&window.CVMarketNative.resolve(" +
                    requestId + "," + (success ? "true" : "false") + "," + JSONObject.quote(result) + ");";
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript(javascript, null);
                });
            }, "cv-market-https").start();
        }
    }
    @Override public void onBackPressed() {
        if (bybitPanel != null) { closeBybitSite(); return; }
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        closeBybitSite();
        if (webView != null) {
            webView.removeJavascriptInterface("CryptoVisionAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
