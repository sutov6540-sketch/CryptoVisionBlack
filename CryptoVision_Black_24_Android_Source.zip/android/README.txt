CRYPTO VISION BLACK 24.0 — ANDROID APP SOURCE

App ID: com.cryptovision.pro
minSdk 26 · compileSdk 35 · targetSdk 35 · JDK 17 · Gradle 8.9

Настоящее Android-приложение на Java + WebView. Веб-интерфейс упакован внутрь
assets; страница открывается через https://appassets.androidplatform.net.
Публичные API Bybit/Binance доступны через строго ограниченный нативный
HTTPS-мост @JavascriptInterface (никаких торговых ключей и ордеров).

Для компиляции: открыть ЭТУ папку в Android Studio и выбрать Build APK(s),
либо поместить android и .github в корень GitHub-репозитория и запустить
Actions > Build Crypto Vision Black 24 APK > Run workflow.

Включённая сеть в устройстве необходима для котировок. APK избегает CORS,
но не снимает ограничения доступа, установленные биржей или сетью.
Проверка реальных API на устройстве не проведена. Готовый APK в исходном
архиве отсутствует.
